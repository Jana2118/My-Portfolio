// annot-check.mjs — element screenshots of the annotated figure + prototype on each case page.
import { createRequire } from "node:module";
const { chromium } = createRequire(import.meta.url)("playwright");
const out = new URL("../qa/shots/", import.meta.url).pathname;
const w = Number(process.argv[2] || 1280);
const b = await chromium.launch();
for (const slug of ["case-study-ota", "case-study-data-sharing", "case-study-accident"]) {
  const p = await b.newPage({ viewport: { width: w, height: 900 } });
  const errs = [];
  p.on("pageerror", (e) => errs.push(e.message));
  p.on("console", (m) => m.type() === "error" && errs.push(m.text()));
  await p.goto(`http://localhost:3000/${slug}.html`, { waitUntil: "networkidle" });
  await (await p.$(".annot__stage")).screenshot({ path: `${out}annot-${slug}-${w}.png` });
  // drive the prototype
  if (slug.endsWith("ota")) { await p.click("[data-ota-start]"); await p.waitForTimeout(3500); }
  if (slug.endsWith("sharing")) { await p.click("tr[data-request='Partner app'] [data-act]"); await p.waitForTimeout(300); }
  if (slug.endsWith("accident")) { await p.click("[data-go='sent']"); await p.waitForTimeout(300); }
  await (await p.$(".proto")).screenshot({ path: `${out}proto-${slug}-${w}.png` });
  const live = await p.$eval(".proto [data-live]", (e) => e.textContent);
  console.log(slug, "live:", JSON.stringify(live), errs.length ? "ERR " + errs.join(" | ") : "");
  await p.close();
}
await b.close();
