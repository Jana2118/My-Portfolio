// og.mjs — renders Open Graph images (1200×630) from the real sky heroes, and
// the PNG app icons. Needs the local server: npx serve .. -l 3000
import { createRequire } from "node:module";
import { mkdirSync } from "node:fs";
const { chromium } = createRequire(import.meta.url)("playwright");
const BASE = process.argv[2] || "http://localhost:3000";
const root = new URL("../assets/", import.meta.url).pathname;
mkdirSync(root + "og", { recursive: true });
mkdirSync(root + "icons", { recursive: true });

const HIDE = `
  .site-nav, .skip-link, .sky__panel, .sky__hint, .sticker, .cs-crumb, .cs-meta, .hero__actions { display: none !important; }
  .sky { min-block-size: 630px !important; --ground-h: 150px !important; }
  .hero__inner { padding-block-start: 70px !important; }
  .cloud, .sky__birds, .sun__rays, .g-beam, .g-boat { animation: none !important; }
`;

const shots = [
  ["og-home", "/", 450],
  ["og-ota", "/case-study-ota.html", 980],
  ["og-data-sharing", "/case-study-data-sharing.html", 1065],
  ["og-accident", "/case-study-accident.html", 1290],
  ["og-grocery", "/case-study-grocery.html", 600],
  ["og-projects", "/projects.html", 1040],
  ["og-mineral", "/case-study-mineral.html", 1000],
  ["og-bkkk", "/case-study-bkkk.html", 1260],
  ["og-builtglory", "/case-study-builtglory.html", 540],
  ["og-rider", "/case-study-rider.html", 820],
];

const browser = await chromium.launch();
for (const [name, path, minutes] of shots) {
  const ctx = await browser.newContext({ viewport: { width: 1200, height: 630 }, deviceScaleFactor: 1, reducedMotion: "reduce" });
  await ctx.addInitScript((m) => localStorage.setItem("jana.sky.v1", JSON.stringify({ minutes: m, mode: "manual" })), minutes);
  const page = await ctx.newPage();
  await page.goto(BASE + path, { waitUntil: "networkidle" });
  await page.addStyleTag({ content: HIDE });
  await page.evaluate(() => document.fonts.ready);
  await page.waitForTimeout(700);
  await page.screenshot({ path: `${root}og/${name}.png`, clip: { x: 0, y: 0, width: 1200, height: 630 } });
  console.log("og", name);
  await ctx.close();
}

// icons: the sun emoji on paper
for (const [file, size] of [["apple-touch-icon.png", 180], ["icon-192.png", 192], ["icon-512.png", 512]]) {
  const page = await browser.newPage({ viewport: { width: size, height: size } });
  await page.setContent(`<html><body style="margin:0;display:grid;place-items:center;width:${size}px;height:${size}px;background:#f7f1e6;font-family:'Noto Color Emoji','Apple Color Emoji',sans-serif"><span style="font-size:${Math.round(size * 0.62)}px;line-height:1">☀️</span></body></html>`);
  await page.waitForTimeout(200);
  await page.screenshot({ path: `${root}icons/${file}` });
  console.log("icon", file);
  await page.close();
}
await browser.close();
