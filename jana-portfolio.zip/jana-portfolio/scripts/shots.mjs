// shots.mjs — Playwright screenshots for visual QA.
// Usage: node shots.mjs [--pages=index,case-study-ota] [--widths=360,768,1280,1920]
//                       [--times=720,1320] [--full] [--scale=1]
// Needs the local server: npx serve .. -l 3000
import { createRequire } from "node:module";
const { chromium } = createRequire(import.meta.url)("playwright"); // preinstalled globally
import { mkdirSync } from "node:fs";
import { fileURLToPath } from "node:url";
import path from "node:path";

const args = Object.fromEntries(
  process.argv.slice(2).map((a) => {
    const [k, v] = a.replace(/^--/, "").split("=");
    return [k, v ?? true];
  })
);
const BASE = args.base || "http://localhost:3000";
const pages = (args.pages || "index,projects,case-study-ota,case-study-data-sharing,case-study-accident,case-study-grocery,case-study-mineral,case-study-bkkk,case-study-builtglory,case-study-rider").split(",");
const widths = (args.widths || "360,768,1280,1920").split(",").map(Number);
const times = (args.times || "720,1320").split(",").map(Number);
const full = !!args.full;
const scale = Number(args.scale || 1);
const heights = { 360: 780, 768: 1024, 1280: 800, 1920: 1080 };

const out = path.join(path.dirname(fileURLToPath(import.meta.url)), "..", "qa", "shots");
mkdirSync(out, { recursive: true });

const browser = await chromium.launch();
for (const p of pages) {
  for (const w of widths) {
    for (const t of times) {
      const ctx = await browser.newContext({
        viewport: { width: w, height: heights[w] || 900 },
        deviceScaleFactor: scale,
        reducedMotion: args.motion === "reduce" ? "reduce" : "no-preference",
      });
      await ctx.addInitScript((m) => {
        localStorage.setItem("jana.sky.v1", JSON.stringify({ minutes: m, mode: "manual" }));
      }, t);
      const page = await ctx.newPage();
      const errors = [];
      page.on("pageerror", (e) => errors.push(e.message));
      page.on("console", (m) => m.type() === "error" && errors.push(m.text()));
      const url = `${BASE}/${p === "index" ? "" : p + ".html"}`;
      await page.goto(url, { waitUntil: "networkidle" });
      await page.evaluate(() => document.fonts.ready);
      await page.waitForTimeout(600);
      const hh = String(Math.floor(t / 60)).padStart(2, "0") + String(t % 60).padStart(2, "0");
      const file = path.join(out, `${p}-${w}-${hh}${full ? "-full" : ""}.png`);
      if (full) {
        // reveal everything that scroll-reveal would hide
        await page.evaluate(() => {
          document.querySelectorAll("[data-reveal], [data-split]").forEach((el) => el.classList.add("is-in"));
          document.querySelector("[data-desk]")?.classList.replace("will-land", "has-landed");
          document.querySelectorAll('img[loading="lazy"]').forEach((img) => (img.loading = "eager"));
        });
        await page.waitForFunction(() => [...document.images].every((i) => i.complete), null, { timeout: 15000 }).catch(() => {});
        await page.waitForTimeout(800);
      }
      await page.screenshot({ path: file, fullPage: full });
      console.log(`${file}${errors.length ? "  ERRORS: " + errors.join(" | ") : ""}`);
      await ctx.close();
    }
  }
}
await browser.close();
