// a11y.mjs — accessibility + integrity checks. Needs: npx serve .. -l 3000
//  1. axe-core (WCAG 2.0/2.1/2.2 A+AA) on every page, day and night, plus open dialogs
//  2. sky contrast sweep: 96 quarter-hours × 3 widths, computed independently from
//     the rendered custom properties (sRGB gradient + haze), text and accent
//  3. keyboard tab walk: every stop visible, with a focus indicator
//  4. reduced motion: content visible, no confetti canvas
//  5. touch: dragging the sun changes the time, swiping elsewhere still scrolls
//  6. console errors + internal links / anchors
import { createRequire } from "node:module";
const require = createRequire(import.meta.url);
const { chromium, devices } = require("playwright");
const AXE = require.resolve("axe-core/axe.min.js");
const BASE = process.argv[2] || "http://localhost:3000";
const PAGES = ["/", "/projects.html", "/case-study-ota.html", "/case-study-data-sharing.html", "/case-study-accident.html", "/case-study-grocery.html", "/case-study-mineral.html", "/case-study-bkkk.html", "/case-study-builtglory.html", "/case-study-rider.html", "/404.html"];
let failures = 0;
const fail = (msg) => {
  failures++;
  console.log("  ✗ " + msg);
};
const ok = (msg) => console.log("  ✓ " + msg);

const browser = await chromium.launch();
const newPage = async (opts = {}, minutes) => {
  const ctx = await browser.newContext({ viewport: { width: 1280, height: 800 }, ...opts });
  if (minutes !== undefined) {
    await ctx.addInitScript((m) => localStorage.setItem("jana.sky.v1", JSON.stringify({ minutes: m, mode: "manual" })), minutes);
  }
  const page = await ctx.newPage();
  page.errors = [];
  page.on("pageerror", (e) => page.errors.push(e.message));
  page.on("console", (m) => m.type() === "error" && page.errors.push(m.text()));
  return page;
};
const axe = async (page, label) => {
  await page.addScriptTag({ path: AXE });
  const res = await page.evaluate(async () =>
    window.axe.run(document, { runOnly: { type: "tag", values: ["wcag2a", "wcag2aa", "wcag21a", "wcag21aa", "wcag22aa", "best-practice"] } })
  );
  const v = res.violations;
  if (!v.length) ok(`axe ${label}: 0 violations (${res.incomplete.length} need review)`);
  for (const x of v) fail(`axe ${label}: ${x.id} (${x.impact}) ×${x.nodes.length}: ${x.nodes.slice(0, 3).map((n) => n.target.join(" ")).join(" | ")}`);
};

/* ---------- 1. axe ---------- */
console.log("\n1 · axe-core");
for (const path of PAGES) {
  for (const [m, theme] of [[720, "day"], [1320, "night"]]) {
    const page = await newPage({ reducedMotion: "reduce" }, m);
    await page.goto(BASE + path, { waitUntil: "networkidle" });
    await axe(page, `${path} ${theme}`);
    if (path === "/") {
      await page.click(".booklet-cover");
      await page.waitForTimeout(200);
      for (let i = 0; i < 5; i++) {
        await axe(page, `${path} ${theme} booklet p${i + 1}`);
        await page.keyboard.press("ArrowRight");
        await page.waitForTimeout(100);
      }
      await page.keyboard.press("Escape");
      await page.waitForTimeout(200);
      await page.click(".cv-folder");
      await page.waitForTimeout(200);
      await axe(page, `${path} ${theme} cv`);
      await page.keyboard.press("Escape");
      // letter with errors shown
      await page.click(".letter [type=submit]");
      await page.waitForTimeout(150);
      await axe(page, `${path} ${theme} letter-errors`);
    }
    if (page.errors.length) fail(`console ${path} ${theme}: ${page.errors.join(" | ")}`);
    await page.context().close();
  }
}

/* ---------- 2. sky contrast sweep ---------- */
console.log("\n2 · sky contrast sweep (text ≥ 4.5, accent heading ≥ 3)");
for (const [w, h] of [[360, 780], [768, 1024], [1280, 800]]) {
  for (const path of ["/", "/case-study-data-sharing.html"]) {
    const page = await newPage({ viewport: { width: w, height: h }, reducedMotion: "reduce" }, 720);
    await page.goto(BASE + path, { waitUntil: "networkidle" });
    const worst = await page.evaluate(async () => {
      const { setMinutes } = await import("/js/time-state.js");
      const hex = (s) => s.trim();
      const parse = (c) => {
        c = c.trim();
        if (c.startsWith("#")) return [1, 3, 5].map((i) => parseInt(c.slice(i, i + 2), 16) / 255);
        const m = c.match(/[\d.]+/g).map(Number);
        return [m[0] / 255, m[1] / 255, m[2] / 255];
      };
      const lin = (v) => (v <= 0.04045 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4);
      const L = (rgb) => 0.2126 * lin(rgb[0]) + 0.7152 * lin(rgb[1]) + 0.0722 * lin(rgb[2]);
      const cr = (a, b) => {
        const x = L(a), y = L(b);
        return (Math.max(x, y) + 0.05) / (Math.min(x, y) + 0.05);
      };
      const mix = (a, b, t) => a.map((v, i) => v + (b[i] - v) * t);
      const sky = document.querySelector("[data-sky]");
      const air = sky.querySelector(".sky__air");
      const raf = () => new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(r)));
      // text nodes in the copy block that sit directly on the sky
      const texts = [...sky.querySelectorAll("[data-sky-copy] .eyebrow, [data-sky-copy] h1, [data-sky-copy] p, [data-sky-copy] dt, [data-sky-copy] dd, [data-sky-copy] .cs-crumb")]
        .filter((el) => !el.closest(".ph"));
      const accents = [...sky.querySelectorAll("[data-sky-copy] h1 .accent")];
      let worstText = { c: 99 }, worstAccent = { c: 99 };
      for (let m = 0; m < 1440; m += 15) {
        setMinutes(m, { persist: false });
        await raf();
        await new Promise((r) => setTimeout(r, 140)); // let the theme switch and 0.01ms transitions settle (60 ms flaked at 06:00 once the page grew)
        const cs = getComputedStyle(sky);
        const top = parse(cs.getPropertyValue("--sky-top"));
        const mid = parse(cs.getPropertyValue("--sky-mid"));
        const bot = parse(cs.getPropertyValue("--sky-bottom"));
        const haze = parse(cs.getPropertyValue("--haze"));
        const hazeA = parseFloat(cs.getPropertyValue("--haze-a")) || 0;
        const a = air.getBoundingClientRect();
        const at = (y) => {
          const f = Math.min(1, Math.max(0, (y - a.top) / a.height));
          const c = f <= 0.55 ? mix(top, mid, f / 0.55) : mix(mid, bot, (f - 0.55) / 0.45);
          return mix(c, haze, hazeA);
        };
        for (const [list, store, key] of [[texts, "t"], [accents, "a"]]) {
          for (const el of list) {
            const r = el.getBoundingClientRect();
            if (!r.height) continue;
            const fg = parse(getComputedStyle(el).color);
            for (const y of [r.top + 2, (r.top + r.bottom) / 2, r.bottom - 2]) {
              const c = cr(fg, at(y));
              const rec = store === "t" ? worstText : worstAccent;
              if (c < rec.c) Object.assign(rec, { c, m, el: el.tagName + "." + el.className });
            }
          }
        }
      }
      return { worstText, worstAccent };
    });
    const t = worst.worstText, a = worst.worstAccent;
    const label = `${path} @${w}px`;
    const hhmm = (m) => `${String(Math.floor(m / 60)).padStart(2, "0")}:${String(m % 60).padStart(2, "0")}`;
    (t.c >= 4.5 ? ok : fail)(`${label}: worst text ${t.c.toFixed(2)}:1 at ${hhmm(t.m)} (${t.el})`);
    (a.c >= 3 ? ok : fail)(`${label}: worst accent heading ${a.c.toFixed(2)}:1 at ${hhmm(a.m)}`);
    await page.context().close();
  }
}

/* ---------- 3. keyboard walk ---------- */
console.log("\n3 · keyboard tab walk");
for (const path of PAGES.filter((p) => p !== "/404.html")) {
  const page = await newPage({ reducedMotion: "reduce" }, 720);
  await page.goto(BASE + path, { waitUntil: "networkidle" });
  const stops = [];
  for (let i = 0; i < 160; i++) {
    await page.keyboard.press("Tab");
    const info = await page.evaluate(() => {
      const el = document.activeElement;
      if (!el || el === document.body) return null;
      const cs = getComputedStyle(el);
      const r = el.getBoundingClientRect();
      const hidden = !!el.closest("[aria-hidden='true'], [inert]") || r.width === 0 || r.height === 0;
      const ring = (cs.outlineStyle !== "none" && parseFloat(cs.outlineWidth) > 0) || cs.boxShadow !== "none";
      const card = el.closest(".card");
      const cardRing = card && getComputedStyle(card).outlineStyle !== "none";
      const name = (el.getAttribute("aria-label") || el.textContent || el.id || el.tagName).trim().replace(/\s+/g, " ").slice(0, 40);
      return { name, tag: el.tagName, hidden, ring: ring || cardRing, key: el.outerHTML.slice(0, 80) };
    });
    if (!info) continue;
    if (stops.length && stops[0].key === info.key) break; // wrapped
    stops.push(info);
  }
  const bad = stops.filter((s) => s.hidden || !s.ring);
  (bad.length ? fail : ok)(`${path}: ${stops.length} tab stops${bad.length ? "; problems: " + bad.map((b) => `${b.name}${b.hidden ? " [hidden]" : ""}${b.ring ? "" : " [no ring]"}`).join(", ") : ", all visible with a focus ring"}`);
  await page.context().close();
}
{
  // range keyboard control + dialog focus return
  const page = await newPage({}, 720);
  await page.goto(BASE + "/", { waitUntil: "networkidle" });
  await page.focus("#sky-range");
  await page.keyboard.press("ArrowRight");
  await page.keyboard.press("PageUp");
  const v = await page.$eval("#sky-range", (e) => [e.value, e.getAttribute("aria-valuetext")]);
  (v[0] === "795" ? ok : fail)(`sky slider: 12:00 → ArrowRight → PageUp = ${v[0]} min, aria-valuetext "${v[1]}"`);
  const themeAfter = await page.evaluate(async () => {
    const { setMinutes } = await import("/js/time-state.js");
    setMinutes(1320);
    return document.documentElement.dataset.theme;
  });
  (themeAfter === "dark" ? ok : fail)(`22:00 switches the site to the dark theme (${themeAfter})`);
  await page.context().close();
}

/* ---------- 4. reduced motion ---------- */
console.log("\n4 · reduced motion");
{
  const page = await newPage({ reducedMotion: "reduce" }, 720);
  await page.goto(BASE + "/", { waitUntil: "networkidle" });
  const hiddenReveal = await page.$$eval("[data-reveal]", (els) => els.filter((e) => getComputedStyle(e).opacity !== "1").length);
  (hiddenReveal === 0 ? ok : fail)(`scroll-reveal content visible without scrolling (${hiddenReveal} hidden)`);
  await page.click("[data-delight]");
  await page.waitForTimeout(100);
  const canvas = await page.$(".confetti");
  const toastText = await page.$eval("[data-toast]", (e) => e.textContent);
  (!canvas && toastText ? ok : fail)(`"Click me" gives a toast without confetti ("${toastText.trim()}")`);
  const anims = await page.evaluate(() => document.getAnimations().filter((a) => a.playState === "running" && a.effect?.getComputedTiming().duration > 50).length);
  (anims === 0 ? ok : fail)(`no long-running animations (${anims})`);
  await page.context().close();
}

/* ---------- 5. touch ---------- */
console.log("\n5 · touch (iPhone 13)");
{
  const ctx = await browser.newContext({ ...devices["iPhone 13"] });
  await ctx.addInitScript(() => localStorage.setItem("jana.sky.v1", JSON.stringify({ minutes: 600, mode: "manual" })));
  const page = await ctx.newPage();
  await page.goto(BASE + "/", { waitUntil: "networkidle" });
  const sun = await page.$('[data-body="sun"]');
  await sun.scrollIntoViewIfNeeded();
  await page.waitForTimeout(800);
  const b = await sun.boundingBox();
  const cdp = await ctx.newCDPSession(page);
  const pt = (x, y) => [{ x, y, id: 1 }];
  const cx = b.x + b.width / 2, cy = b.y + b.height / 2;
  await cdp.send("Input.dispatchTouchEvent", { type: "touchStart", touchPoints: pt(cx, cy) });
  for (let i = 1; i <= 10; i++) await cdp.send("Input.dispatchTouchEvent", { type: "touchMove", touchPoints: pt(cx + i * 12, cy + i * 2) });
  await cdp.send("Input.dispatchTouchEvent", { type: "touchEnd", touchPoints: [] });
  await page.waitForTimeout(300);
  const m = await page.evaluate(() => JSON.parse(localStorage.getItem("jana.sky.v1")).minutes);
  (m > 640 ? ok : fail)(`dragging the sun with a finger moved the time from 10:00 to ${Math.floor(m / 60)}:${String(m % 60).padStart(2, "0")}`);
  await page.evaluate(() => scrollTo(0, 0));
  await page.waitForTimeout(200);
  // swipe up on the headline (not on the sun)
  const sx = 120, sy = 420;
  await cdp.send("Input.dispatchTouchEvent", { type: "touchStart", touchPoints: pt(sx, sy) });
  for (let i = 1; i <= 12; i++) await cdp.send("Input.dispatchTouchEvent", { type: "touchMove", touchPoints: pt(sx, sy - i * 25) });
  await cdp.send("Input.dispatchTouchEvent", { type: "touchEnd", touchPoints: [] });
  await page.waitForTimeout(600);
  const after = await page.evaluate(() => scrollY);
  (after > 100 ? ok : fail)(`swiping the hero still scrolls the page (scrollY ${after})`);
  await ctx.close();
}

/* ---------- 5b. no horizontal overflow at phone width ---------- */
console.log("\n5b · no sideways scrolling at 360 px");
for (const path of [...PAGES, "/case-study-template.html"]) {
  const page = await newPage({ viewport: { width: 360, height: 780 }, reducedMotion: "reduce" }, 720);
  await page.goto(BASE + path, { waitUntil: "networkidle" });
  const r = await page.evaluate(() => {
    const w = document.documentElement.clientWidth;
    const wide = [...document.querySelectorAll("body *")]
      .filter((el) => {
        const b = el.getBoundingClientRect();
        if (!b.width || b.right <= w + 1) return false;
        // ignore content inside intentional sideways scrollers, and anything a parent already clips
        if (el.closest(".proto__scroll, .annot__stage, .confetti, pre, dialog:not([open])")) return false;
        for (let p = el.parentElement; p && p !== document.body; p = p.parentElement) {
          const o = getComputedStyle(p).overflowX;
          if (o === "hidden" || o === "clip") return false;
        }
        return true;
      })
      .slice(0, 4)
      .map((el) => `${el.tagName.toLowerCase()}.${[...el.classList].join(".")} (${Math.round(el.getBoundingClientRect().right)}px)`);
    return { scroll: document.documentElement.scrollWidth, w, wide };
  });
  (r.scroll <= r.w && !r.wide.length ? ok : fail)(`${path}: page ${r.scroll}px in a ${r.w}px viewport${r.wide.length ? "; too wide: " + r.wide.join(", ") : ""}`);
  await page.context().close();
}

/* ---------- 5c. well-formed HTML (browsers silently repair stray tags) ---------- */
console.log("\n5c · well-formed HTML");
{
  const { readFileSync, readdirSync } = await import("node:fs");
  const root = new URL("../", import.meta.url).pathname;
  const VOID = new Set(["area", "base", "br", "col", "embed", "hr", "img", "input", "link", "meta", "source", "track", "wbr", "path", "circle", "rect", "ellipse", "use", "stop", "polygon", "line"]);
  for (const f of readdirSync(root).filter((n) => n.endsWith(".html"))) {
    const src = readFileSync(root + f, "utf8").replace(/<!--[\s\S]*?-->/g, "").replace(/<(script|style)[\s\S]*?<\/\1>/g, "");
    const stack = [];
    const errs = [];
    for (const m of src.matchAll(/<\/?([a-zA-Z][\w-]*)[^>]*?(\/?)>/g)) {
      const tag = m[1].toLowerCase();
      if (VOID.has(tag) || m[2] === "/" || tag === "!doctype") continue;
      if (m[0].startsWith("</")) {
        if (stack.at(-1) === tag) stack.pop();
        else errs.push(`unexpected </${tag}> (open: <${stack.at(-1) || "none"}>)`);
      } else stack.push(tag);
    }
    const open = stack.filter((t) => !["html", "head", "body"].includes(t));
    (errs.length || open.length ? fail : ok)(`${f}: ${errs.length || open.length ? errs.slice(0, 3).join("; ") + (open.length ? " unclosed: " + open.slice(-3).join(",") : "") : "balanced"}`);
  }
}

/* ---------- 6. links ---------- */
console.log("\n6 · links and anchors");
{
  const page = await newPage({}, 720);
  const seen = new Map();
  for (const path of PAGES) {
    await page.goto(BASE + path, { waitUntil: "networkidle" });
    const links = await page.$$eval("a[href]", (as) => as.map((a) => ({ href: a.href, raw: a.getAttribute("href") })));
    for (const l of links) if (!seen.has(l.href)) seen.set(l.href, path);
  }
  const external = [];
  for (const [href, from] of seen) {
    const u = new URL(href);
    if (!u.protocol.startsWith("http")) continue;
    if (!href.startsWith(BASE)) {
      external.push(href);
      continue;
    }
    const res = await page.request.get(u.origin + u.pathname, { maxRedirects: 5 });
    const isResume = u.pathname.endsWith("Janarthanan_V_Resume.pdf");
    if (!res.ok()) (isResume ? console.log(`  • ${u.pathname} → ${res.status()} (expected: résumé PDF not supplied yet; links show a toast)`) : fail(`${u.pathname} → ${res.status()} (from ${from})`));
    if (u.hash && u.hash.length > 1) {
      await page.goto(u.origin + u.pathname, { waitUntil: "domcontentloaded" });
      const exists = await page.$(u.hash);
      if (!exists) fail(`missing anchor ${u.pathname}${u.hash} (from ${from})`);
    }
  }
  ok(`${seen.size} unique hrefs checked; external: ${external.length ? external.join(", ") : "none"}`);
  await page.context().close();
}

await browser.close();
console.log(`\n${failures ? `✗ ${failures} problem(s)` : "✓ all checks passed"}`);
process.exit(failures ? 1 : 0);
