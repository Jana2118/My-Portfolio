// motion-check.mjs — frames of the hero intro + scroll-triggered motion, as a contact sheet.
import { createRequire } from "node:module";
const { chromium } = createRequire(import.meta.url)("playwright");
const out = new URL("../qa/shots/", import.meta.url).pathname;
const minutes = Number(process.argv[2] || 600);
const b = await chromium.launch();
const ctx = await b.newContext({ viewport: { width: 1280, height: 800 } });
await ctx.addInitScript((m) => localStorage.setItem("jana.sky.v1", JSON.stringify({ minutes: m, mode: "manual" })), minutes);
const p = await ctx.newPage();
const errs = [];
p.on("pageerror", (e) => errs.push(e.message));
p.on("console", (m) => m.type() === "error" && errs.push(m.text()));
await p.goto("http://localhost:3000/", { waitUntil: "commit" });
const t0 = Date.now();
for (const ms of [250, 700, 1200, 2600]) {
  await p.waitForTimeout(Math.max(0, ms - (Date.now() - t0)));
  await p.screenshot({ path: `${out}intro-${ms}.png` });
}
// scroll to work: heading words + ribbon + count-up mid-way
await p.evaluate(() => document.getElementById("work").scrollIntoView({ behavior: "instant" }));
await p.waitForTimeout(450);
await p.screenshot({ path: `${out}work-mid.png` });
await p.waitForTimeout(1800);
await p.screenshot({ path: `${out}work-end.png` });
// desk landing mid-way
await p.evaluate(() => document.getElementById("desk").scrollIntoView({ block: "center", behavior: "instant" }));
await p.waitForTimeout(350);
await p.screenshot({ path: `${out}desk-mid.png` });
await p.waitForTimeout(1800);
await p.screenshot({ path: `${out}desk-end.png` });
// tilt a card
await p.evaluate(() => document.querySelector(".card").scrollIntoView({ block: "center", behavior: "instant" }));
await p.waitForTimeout(400);
const c = await (await p.$(".card")).boundingBox();
await p.mouse.move(c.x + c.width * 0.85, c.y + c.height * 0.2, { steps: 8 });
await p.waitForTimeout(500);
await p.screenshot({ path: `${out}tilt.png` });
console.log(errs.length ? "ERRORS: " + errs.join(" | ") : "no console errors");
await b.close();
