// desk-check.mjs — screenshot the desk on mobile and the two dialogs open.
import { createRequire } from "node:module";
const { chromium } = createRequire(import.meta.url)("playwright");
const out = new URL("../qa/shots/", import.meta.url).pathname;
const b = await chromium.launch();
for (const [w, h, t] of [[360, 780, 720], [1280, 800, 720], [1280, 800, 1320]]) {
  const ctx = await b.newContext({ viewport: { width: w, height: h } });
  await ctx.addInitScript((m) => localStorage.setItem("jana.sky.v1", JSON.stringify({ minutes: m, mode: "manual" })), t);
  const p = await ctx.newPage();
  const errs = [];
  p.on("pageerror", (e) => errs.push(e.message));
  p.on("console", (m) => m.type() === "error" && errs.push(m.text()));
  await p.goto("http://localhost:3000/", { waitUntil: "networkidle" });
  if (w === 360) {
    await p.evaluate(() => document.querySelectorAll("[data-reveal]").forEach((el) => el.classList.add("is-in")));
    const el = await p.$("#desk");
    await el.screenshot({ path: out + `desk-${w}.png` });
  }
  await p.click(".booklet-cover");
  await p.waitForTimeout(800);
  await p.screenshot({ path: out + `dlg-story-${w}-${t}-0.png` });
  await p.keyboard.press("ArrowRight");
  await p.waitForTimeout(800);
  await p.screenshot({ path: out + `dlg-story-${w}-${t}-1.png` });
  const focused = await p.evaluate(() => document.activeElement?.getAttribute("aria-label") || document.activeElement?.textContent);
  await p.keyboard.press("Escape");
  await p.waitForTimeout(600);
  const back = await p.evaluate(() => document.activeElement?.className);
  await p.click(".cv-folder");
  await p.waitForTimeout(900);
  await p.screenshot({ path: out + `dlg-cv-${w}-${t}.png` });
  console.log(w, t, "focus in booklet:", focused, "| focus after Esc:", back, errs.length ? "ERR " + errs.join(" | ") : "");
  await ctx.close();
}
await b.close();
