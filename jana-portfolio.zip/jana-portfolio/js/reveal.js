/* reveal.js — gentle scroll-in for [data-reveal]. Content is visible by
   default; the hidden start state only applies with JS + motion allowed. */
export function initReveal() {
  const items = document.querySelectorAll("[data-reveal]");
  if (!items.length) return;
  if (matchMedia("(prefers-reduced-motion: reduce)").matches || !("IntersectionObserver" in window)) return;
  document.documentElement.classList.add("reveal-on");
  const io = new IntersectionObserver(
    (entries) => {
      for (const e of entries) {
        if (!e.isIntersecting) continue;
        e.target.classList.add("is-in");
        io.unobserve(e.target);
      }
    },
    { rootMargin: "0px 0px -8% 0px", threshold: 0.08 }
  );
  items.forEach((el, i) => {
    el.style.setProperty("--reveal-delay", `${(i % 3) * 70}ms`);
    io.observe(el);
  });
}
