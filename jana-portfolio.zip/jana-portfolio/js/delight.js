/* delight.js — the "Click me 👆" pill. Bursts paper confetti plus a few emoji
   from the pill, then a witty toast. Reduced motion: toast only. */
import { toast } from "./toast.js";

const LINES = [
  ["You clicked. Task success rate: 100%.", "🎉"],
  ["Clear affordance, right? That's the job.", "👆"],
  ["Again? Love the engagement.", "📈"],
  ["Okay, you found all the confetti.", "✨"],
];

export function initDelight(btn) {
  let n = 0;
  const reduce = matchMedia("(prefers-reduced-motion: reduce)");
  btn.addEventListener("click", () => {
    const [msg, emoji] = LINES[n % LINES.length];
    n++;
    btn.classList.remove("is-pop");
    void btn.offsetWidth; // restart the CSS pop
    btn.classList.add("is-pop");
    if (!reduce.matches) burst(btn);
    toast(msg, { emoji });
  });
}

function burst(origin) {
  const canvas = document.createElement("canvas");
  canvas.className = "confetti";
  canvas.setAttribute("aria-hidden", "true");
  document.body.appendChild(canvas);
  const dpr = Math.min(2, window.devicePixelRatio || 1);
  const W = innerWidth;
  const H = innerHeight;
  canvas.width = W * dpr;
  canvas.height = H * dpr;
  const ctx = canvas.getContext("2d");
  ctx.scale(dpr, dpr);

  const css = getComputedStyle(document.documentElement);
  const colors = ["--c-accent", "--c-sun", "--c-leaf", "--c-sky", "--c-amber"].map((v) => css.getPropertyValue(v).trim());
  const glyphs = ["✏️", "✨", "🎨", "💡", "🧩"];
  const r = origin.getBoundingClientRect();
  const ox = r.left + r.width / 2;
  const oy = r.top + r.height / 2;

  const parts = Array.from({ length: 90 }, (_, i) => {
    const a = -Math.PI / 2 + (Math.random() - 0.5) * Math.PI * 1.3;
    const v = 6 + Math.random() * 9;
    return {
      x: ox,
      y: oy,
      vx: Math.cos(a) * v,
      vy: Math.sin(a) * v,
      w: 6 + Math.random() * 6,
      h: 8 + Math.random() * 8,
      rot: Math.random() * Math.PI,
      vr: (Math.random() - 0.5) * 0.3,
      color: colors[i % colors.length],
      glyph: i % 9 === 0 ? glyphs[Math.floor(i / 9) % glyphs.length] : null,
      life: 0,
    };
  });

  let frame = 0;
  const step = () => {
    frame++;
    ctx.clearRect(0, 0, W, H);
    let alive = 0;
    for (const p of parts) {
      p.vy += 0.28;
      p.vx *= 0.985;
      p.vy *= 0.985;
      p.x += p.vx;
      p.y += p.vy;
      p.rot += p.vr;
      p.life++;
      if (p.y > H + 40) continue;
      alive++;
      ctx.globalAlpha = Math.max(0, 1 - p.life / 140);
      ctx.save();
      ctx.translate(p.x, p.y);
      ctx.rotate(p.rot);
      if (p.glyph) {
        ctx.font = "20px 'Apple Color Emoji','Segoe UI Emoji','Noto Color Emoji',sans-serif";
        ctx.fillText(p.glyph, -10, 8);
      } else {
        ctx.fillStyle = p.color;
        ctx.fillRect(-p.w / 2, -p.h / 2, p.w, p.h * Math.abs(Math.cos(p.life / 6)));
      }
      ctx.restore();
    }
    if (alive && frame < 200) requestAnimationFrame(step);
    else canvas.parentNode?.removeChild(canvas);
  };
  requestAnimationFrame(step);
}
