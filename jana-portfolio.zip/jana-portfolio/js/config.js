/* ==========================================================================
   config.js — the ONE place for contact details, URLs and feature flags.
   Fill the [PLACEHOLDER] values here; HTML and JS read from this file.
   ========================================================================== */

/** Absolute site origin, no trailing slash. [PLACEHOLDER] — also swap it in
 *  the HTML <head> tags, sitemap.xml and robots.txt (see CLAUDE.md). */
export const SITE_URL = "https://YOUR-DOMAIN.vercel.app";

/** Contact details are stored in parts and assembled at runtime, so the raw
 *  address and number never appear in the HTML source (scraper deterrent). */
export const CONTACT = {
  emailUser: "janauxui",
  emailDomain: "gmail.com",
  phoneCountry: "+91",
  phoneNational: "7010399595",
};

export const LINKS = {
  /** LinkedIn profile URL (the desk stamp links here). */
  linkedin: "https://www.linkedin.com/in/janarthanan-v-04a07b367/",
  /** wa.me deep link. Only shown as a chat action; see `whatsappConfirmed`. */
  whatsapp: "https://wa.me/917010399595",
  /** Confirmed by Jana (Nov 2026): the same number is on WhatsApp. */
  whatsappConfirmed: true,
  /** Optional portfolio profiles. Empty = the tag is not rendered at all. */
  behance: "",
  dribbble: "",
  /** Résumé PDF (from Jana, Nov 2026). If the file is ever missing, résumé
   *  links show a friendly toast instead of a 404. */
  resume: "assets/Janarthanan_V_Resume.pdf",
};

export const email = () => `${CONTACT.emailUser}@${CONTACT.emailDomain}`;
export const phoneE164 = () => `${CONTACT.phoneCountry}${CONTACT.phoneNational}`;
export const phonePretty = () =>
  `${CONTACT.phoneCountry} ${CONTACT.phoneNational.slice(0, 5)} ${CONTACT.phoneNational.slice(5)}`;

/** "jan•••••@gmail.com" */
export const emailMasked = () =>
  `${CONTACT.emailUser.slice(0, 3)}${"•".repeat(Math.max(3, CONTACT.emailUser.length - 3))}@${CONTACT.emailDomain}`;

/** "+91 70••• •••95" */
export const phoneMasked = () => {
  const n = CONTACT.phoneNational;
  return `${CONTACT.phoneCountry} ${n.slice(0, 2)}••• •••${n.slice(-2)}`;
};

/** localStorage keys (versioned so a format change can't break old visitors). */
export const STORAGE = {
  sky: "jana.sky.v1",
};
