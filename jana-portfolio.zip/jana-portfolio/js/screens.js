/* screens.js — case-study screens, "light & tide" (styles at the end of
   css/case-study.css).
   · Desktop screens and HTML recreations are swept by a beam of light and
     "develop" from washed-out to full colour. The beam comes from the side the
     sun is on (--light-x from the sky); at night it's the lighthouse, on the right.
   · Phones surface from a waterline, bob once and leave two ripples.
   · Screens in a gallery are lit one after another; captions follow.
   · Once lit, a soft glare on each desktop screen follows the sun (and the
     pointer on hover).
   Does nothing under prefers-reduced-motion, so every screen stays visible. */
const reduce = matchMedia("(prefers-reduced-motion: reduce)");

const SWEEP = [
  ".cs-cover > .shot",
  ".cs-mockcover:not(.cs-mockcover--phone)",
  ".gallery__item > .shot--browser",
  ".solution__media .shot--browser",
  ".annot__stage",
].join(", ");
const TIDE = [".gallery__item > .shot--phone", ".solution__media .shot--phone", ".cs-mockcover--phone"].join(", ");

export function initScreens(root = document) {
  if (reduce.matches || !("IntersectionObserver" in window)) return;
  const sweeps = [...root.querySelectorAll(SWEEP)];
  const tides = [...root.querySelectorAll(TIDE)].filter((el) => el.querySelector(":scope > picture, :scope > .mock-phone"));
  if (!sweeps.length && !tides.length) return;

  sweeps.forEach((el) => (el.dataset.light = "sweep"));
  tides.forEach((el) => (el.dataset.light = "tide"));
  // stagger: index within each gallery (set on the figure so its caption shares it)
  for (const g of root.querySelectorAll(".gallery")) {
    [...g.children].forEach((item, k) => item.style.setProperty("--k", String(Math.min(k, 6))));
  }
  document.documentElement.classList.add("screens-on");

  // Watch each screen's container: a fully clipped screen never counts as visible.
  const byHost = new Map();
  for (const el of [...sweeps, ...tides]) {
    const host = el.parentElement;
    byHost.set(host, [...(byHost.get(host) || []), el]);
  }
  const io = new IntersectionObserver(
    (entries) => {
      for (const e of entries) {
        if (!e.isIntersecting) continue;
        io.unobserve(e.target);
        byHost.get(e.target).forEach(light);
      }
    },
    { threshold: 0.18, rootMargin: "0px 0px -6% 0px" }
  );
  byHost.forEach((_, host) => io.observe(host));

  // glare follows the pointer while hovering a lit screen
  for (const el of sweeps) {
    el.addEventListener("pointermove", (e) => {
      if (!el.classList.contains("is-done")) return;
      const r = el.getBoundingClientRect();
      el.style.setProperty("--gx", ((e.clientX - r.left) / r.width - 0.5).toFixed(3));
    });
    el.addEventListener("pointerleave", () => el.style.removeProperty("--gx"));
  }
}

/** Which side the light comes from: the sun's side by day, the lighthouse (right) by night. */
function lightSide() {
  const root = document.documentElement;
  if (root.dataset.theme === "dark") return "right";
  const x = parseFloat(getComputedStyle(root).getPropertyValue("--light-x")) || 0;
  return x > 0.12 ? "right" : "left";
}

async function light(el) {
  // wait for the screenshot so the beam never reveals an empty frame
  const img = el.querySelector("img");
  if (img && !img.complete) {
    await Promise.race([img.decode().catch(() => {}), new Promise((r) => setTimeout(r, 1500))]);
  }
  if (el.dataset.light === "sweep") {
    el.dataset.from = lightSide();
    el.addEventListener("animationend", function done(e) {
      if (e.target !== el || e.animationName !== "screen-develop") return;
      el.removeEventListener("animationend", done);
      el.classList.add("is-done");
    });
  }
  el.classList.add("is-lit");
}
