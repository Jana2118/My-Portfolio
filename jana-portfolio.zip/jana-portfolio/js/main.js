/* main.js — entry point. Each feature initialises only if its hook exists. */
import "./time-state.js";
import { initSky } from "./sky.js";
import { initNav, initResumeLinks } from "./nav.js";
import { initDelight } from "./delight.js";
import { initReveal } from "./reveal.js";
import { initDialogs } from "./dialog.js";
import { initMotion } from "./motion.js";

const $ = (s) => document.querySelector(s);
const $$ = (s) => document.querySelectorAll(s);

$$("[data-sky]").forEach(initSky);
const nav = $("[data-nav]");
if (nav) initNav(nav);
initResumeLinks();
$$("[data-delight]").forEach(initDelight);
initDialogs();

const lazy = [
  ["[data-work]", () => import("./work.js").then((m) => m.initWork($("[data-work]")))],
  ["[data-desk]", () => import("./desk.js").then((m) => m.initDesk($("[data-desk]")))],
  ["[data-contact]", () => import("./contact.js").then((m) => m.initContact(document))],
  ["[data-proto]", () => import("./prototypes.js").then((m) => m.initPrototypes(document))],
  ["[data-projects]", () => import("./projects.js").then((m) => m.initProjects($("[data-projects]")))],
  [".cs-article", () => import("./screens.js").then((m) => m.initScreens(document))],
  ["[data-about]", () => import("./about.js").then((m) => m.initAbout($("[data-about]")))],
  ["[data-sky]:not(.sky--compact)", () => import("./sky-craft.js").then((m) => m.initSkyCraft($("[data-sky]:not(.sky--compact)")))],
];
for (const [sel, load] of lazy) {
  if ($(sel)) load().catch((e) => console.warn(`[jana] ${sel} failed to init`, e));
}

initMotion();
initReveal();
document.documentElement.classList.add("is-booted");
