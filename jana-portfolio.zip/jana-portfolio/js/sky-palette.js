/* ==========================================================================
   sky-palette.js — pure colour maths (no DOM; importable from Node for QA).
   Keyframes are interpolated in OKLab so dawn/dusk blend without mud.
   Text colour is chosen for contrast against the actual sky behind the copy,
   and a soft haze is added only when no text colour can reach AA alone.
   ========================================================================== */

/** Keyframes. t = minutes after midnight. Colours: sky gradient (top/mid/bottom),
 *  scene layers (hill1 far coast, hill2 shore, hill3 foreground silhouettes), sea,
 *  cloud tint, and star visibility. */
export const KEYS = [
  { t: 0,    top: "#070b1f", mid: "#0f1636", bottom: "#1b2350", hill1: "#1b2350", hill2: "#2a2c4a", hill3: "#070a1a", sea: "#0e1534", cloud: "#262f5a", star: 1 },
  { t: 270,  top: "#0b1029", mid: "#161c45", bottom: "#262a5a", hill1: "#20265a", hill2: "#2e3052", hill3: "#090c1f", sea: "#121b40", cloud: "#2c3463", star: 0.9 },
  { t: 330,  top: "#1a1f4c", mid: "#2f3062", bottom: "#4f4473", hill1: "#3a3b6a", hill2: "#4a4566", hill3: "#15162e", sea: "#2a3463", cloud: "#3c3a6c", star: 0.45 },
  { t: 375,  top: "#8f9ad0", mid: "#e0aabb", bottom: "#f8c8a2", hill1: "#9a86a8", hill2: "#d9b49a", hill3: "#3a3050", sea: "#8b8fc0", cloud: "#fde9e0", star: 0.04 },
  { t: 450,  top: "#8cc4ec", mid: "#c6e2f4", bottom: "#fbe6c8", hill1: "#8fb4b0", hill2: "#e8cfa4", hill3: "#2f4a45", sea: "#5b9cc8", cloud: "#ffffff", star: 0 },
  { t: 720,  top: "#6aaee8", mid: "#a5d3f4", bottom: "#e2f3fc", hill1: "#7fb0a4", hill2: "#ecd6a8", hill3: "#24443b", sea: "#3f8cc6", cloud: "#ffffff", star: 0 },
  { t: 960,  top: "#7bb2e2", mid: "#b8d9ef", bottom: "#f8e0b8", hill1: "#9ab19a", hill2: "#e9cc98", hill3: "#2f4638", sea: "#4c8fbf", cloud: "#fffaf0", star: 0 },
  { t: 1065, top: "#a8c0dc", mid: "#f3c690", bottom: "#f6b07a", hill1: "#c08a6a", hill2: "#e8b47e", hill3: "#3e2a24", sea: "#d9946e", cloud: "#ffe4c4", star: 0 },
  { t: 1110, top: "#2c2c66", mid: "#4f3a73", bottom: "#8a4f6a", hill1: "#5a3d68", hill2: "#7a4c5a", hill3: "#1c1428", sea: "#4a3a70", cloud: "#5a4677", star: 0.15 },
  { t: 1170, top: "#0c1134", mid: "#1a1e4c", bottom: "#33305f", hill1: "#262a58", hill2: "#33324f", hill3: "#0a0c20", sea: "#151c44", cloud: "#2e3466", star: 0.8 },
  { t: 1440, top: "#070b1f", mid: "#0f1636", bottom: "#1b2350", hill1: "#1b2350", hill2: "#2a2c4a", hill3: "#070a1a", sea: "#0e1534", cloud: "#262f5a", star: 1 },
];

export const TEXT = {
  ink: "#1f1a15",
  ink2: "#3a2f25",
  cream: "#fbf6ec",
  cream2: "#e9dfce",
  accentDark: "#922a17", // on light skies
  accentLight: "#ffa184", // on dark skies
  hazeDark: "#0b1029",
  hazeLight: "#fff8ec",
};

/** Site theme: night between 18:30 and 06:00. */
export const isNight = (m) => m < 360 || m >= 1110;

/* ---------- colour space helpers ---------- */
export const hexToRgb = (hex) => {
  const h = hex.replace("#", "");
  return [0, 2, 4].map((i) => parseInt(h.slice(i, i + 2), 16) / 255);
};
export const rgbToHex = (rgb) =>
  "#" + rgb.map((v) => Math.round(Math.min(1, Math.max(0, v)) * 255).toString(16).padStart(2, "0")).join("");

const toLin = (v) => (v <= 0.04045 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4);
const toSrgb = (v) => (v <= 0.0031308 ? 12.92 * v : 1.055 * v ** (1 / 2.4) - 0.055);

function rgbToOklab([r, g, b]) {
  const [lr, lg, lb] = [toLin(r), toLin(g), toLin(b)];
  const l = Math.cbrt(0.4122214708 * lr + 0.5363325363 * lg + 0.0514459929 * lb);
  const m = Math.cbrt(0.2119034982 * lr + 0.6806995451 * lg + 0.1073969566 * lb);
  const s = Math.cbrt(0.0883024619 * lr + 0.2817188376 * lg + 0.6299787005 * lb);
  return [
    0.2104542553 * l + 0.793617785 * m - 0.0040720468 * s,
    1.9779984951 * l - 2.428592205 * m + 0.4505937099 * s,
    0.0259040371 * l + 0.7827717662 * m - 0.808675766 * s,
  ];
}
function oklabToRgb([L, a, b]) {
  const l = (L + 0.3963377774 * a + 0.2158037573 * b) ** 3;
  const m = (L - 0.1055613458 * a - 0.0638541728 * b) ** 3;
  const s = (L - 0.0894841775 * a - 1.291485548 * b) ** 3;
  return [
    toSrgb(4.0767416621 * l - 3.3077115913 * m + 0.2309699292 * s),
    toSrgb(-1.2684380046 * l + 2.6097574011 * m - 0.3413193965 * s),
    toSrgb(-0.0041960863 * l - 0.7034186147 * m + 1.707614701 * s),
  ];
}

/** Perceptual mix of two hex colours. */
export function mix(a, b, t) {
  const A = rgbToOklab(hexToRgb(a));
  const B = rgbToOklab(hexToRgb(b));
  return rgbToHex(oklabToRgb(A.map((v, i) => v + (B[i] - v) * t)));
}

/** Alpha-composite `top` over `bottom` (sRGB, as browsers do). */
export function over(top, alpha, bottom) {
  const T = hexToRgb(top);
  const B = hexToRgb(bottom);
  return rgbToHex(T.map((v, i) => v * alpha + B[i] * (1 - alpha)));
}

export function luminance(hex) {
  const [r, g, b] = hexToRgb(hex).map(toLin);
  return 0.2126 * r + 0.7152 * g + 0.0722 * b;
}
export function contrast(a, b) {
  const x = luminance(a);
  const y = luminance(b);
  return (Math.max(x, y) + 0.05) / (Math.min(x, y) + 0.05);
}

const smooth = (t) => t * t * (3 - 2 * t);

/** Interpolated sky for a given minute (0–1439). */
export function sampleSky(minutes) {
  const m = ((minutes % 1440) + 1440) % 1440;
  let i = 0;
  while (i < KEYS.length - 2 && KEYS[i + 1].t <= m) i++;
  const a = KEYS[i];
  const b = KEYS[i + 1];
  const t = smooth((m - a.t) / (b.t - a.t));
  const out = { minutes: m };
  for (const k of ["top", "mid", "bottom", "hill1", "hill2", "hill3", "sea", "cloud"]) out[k] = mix(a[k], b[k], t);
  out.star = a.star + (b.star - a.star) * t;
  return out;
}

/** Straight sRGB mix: how CSS linear-gradient interpolates by default. */
export function mixSrgb(a, b, t) {
  const A = hexToRgb(a);
  const B = hexToRgb(b);
  return rgbToHex(A.map((v, i) => v + (B[i] - v) * t));
}

/** Colour of the sky gradient at vertical fraction f (0 top → 1 horizon).
 *  Matches the CSS: top 0%, mid at `midStop`, bottom at 100%, sRGB. */
export function skyAt(sky, f, midStop = 0.55) {
  if (f <= midStop) return mixSrgb(sky.top, sky.mid, f / midStop);
  return mixSrgb(sky.mid, sky.bottom, (f - midStop) / (1 - midStop));
}

/** Decide hero text colours for the copy region [f0, f1] of the sky.
 *  Returns text, text2, accent, and the minimum haze (colour + alpha) needed so
 *  every sample reaches `target` contrast. Clouds are included as potential
 *  backgrounds (composited at `cloudAlpha`). */
export function pickText(sky, { f0 = 0.2, f1 = 0.8, cloudAlpha = 0.9, target = 4.6, accentTarget = 3.2, midStop = 0.55 } = {}) {
  const samples = [];
  for (let i = 0; i <= 8; i++) samples.push(skyAt(sky, f0 + ((f1 - f0) * i) / 8, midStop));
  samples.push(...samples.slice(0, 5).map((c) => over(sky.cloud, cloudAlpha, c)));

  const options = [
    { text: TEXT.ink, text2: TEXT.ink2, accent: TEXT.accentDark, haze: TEXT.hazeLight, scheme: "light" },
    { text: TEXT.cream, text2: TEXT.cream2, accent: TEXT.accentLight, haze: TEXT.hazeDark, scheme: "dark" },
  ];
  let best = null;
  for (const o of options) {
    for (let a = 0; a <= 0.9001; a += 0.05) {
      const bgs = a === 0 ? samples : samples.map((c) => over(o.haze, a, c));
      const minText = Math.min(...bgs.map((c) => Math.min(contrast(o.text, c), contrast(o.text2, c))));
      const minAccent = Math.min(...bgs.map((c) => contrast(o.accent, c)));
      if (minText >= target && minAccent >= accentTarget) {
        if (!best || a < best.hazeAlpha) best = { ...o, hazeAlpha: +a.toFixed(2), minText, minAccent };
        break;
      }
    }
  }
  return best;
}

/** Human labels for the readout and the slider's aria-valuetext. */
export function phaseOf(m) {
  if (m < 300) return { phase: "night", weather: "Clear night", icon: "🌙" };
  if (m < 360) return { phase: "before dawn", weather: "First light", icon: "🌌" };
  if (m < 450) return { phase: "dawn", weather: "Sunrise", icon: "🌅" };
  if (m < 720) return { phase: "morning", weather: "Clear", icon: "☀️" };
  if (m < 1020) return { phase: "afternoon", weather: "Clear", icon: "☀️" };
  if (m < 1110) return { phase: "golden hour", weather: "Golden hour", icon: "🌇" };
  if (m < 1170) return { phase: "dusk", weather: "Dusk", icon: "🌆" };
  return { phase: "night", weather: "Clear night", icon: "🌙" };
}

export const fmt = (m) => {
  const mm = ((Math.round(m) % 1440) + 1440) % 1440;
  return `${String(Math.floor(mm / 60)).padStart(2, "0")}:${String(mm % 60).padStart(2, "0")}`;
};
