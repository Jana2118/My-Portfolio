/* contact.js — everything that reaches Jana: masked email + copy, the phone
   reveal, LinkedIn stamp, optional profile tags, the letter form (validated,
   then handed to the visitor's mail app) and the Chennai clock note. */
import { LINKS, email, emailMasked, phoneE164, phonePretty, phoneMasked } from "./config.js";
import { copyText } from "./clipboard.js";
import { toast } from "./toast.js";

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

export function initContact(scope = document) {
  const addr = email();

  /* masked address + mailto links */
  scope.querySelectorAll("[data-email-masked]").forEach((el) => (el.textContent = emailMasked()));
  scope.querySelectorAll("[data-mailto]").forEach((a) => {
    a.href = `mailto:${addr}?subject=${encodeURIComponent("Hello Jana")}`;
  });

  /* copy address */
  scope.querySelectorAll("[data-copy-email]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const ok = await copyText(addr);
      toast(ok ? `Copied ${addr}. Paste it anywhere.` : `Couldn't copy. The address is ${addr}`, { emoji: ok ? "📋" : "✉️" });
    });
  });

  /* phone: masked until asked */
  scope.querySelectorAll("[data-phone]").forEach((el) => (el.textContent = phoneMasked()));
  scope.querySelectorAll("[data-reveal-phone]").forEach((btn) => {
    const card = btn.closest(".biz-card");
    const out = card?.querySelector("[data-phone]");
    const links = document.getElementById(btn.getAttribute("aria-controls"));
    const tel = links?.querySelector("[data-tel]");
    const wa = links?.querySelector("[data-whatsapp]");
    const confirmPh = links?.querySelector("[data-whatsapp-confirm]");
    if (tel) tel.href = `tel:${phoneE164()}`;
    if (wa) wa.href = LINKS.whatsapp;
    if (confirmPh) confirmPh.hidden = LINKS.whatsappConfirmed;
    btn.addEventListener("click", () => {
      const open = btn.getAttribute("aria-expanded") !== "true";
      btn.setAttribute("aria-expanded", String(open));
      btn.textContent = open ? "Hide number" : "Reveal number";
      if (out) out.textContent = open ? phonePretty() : phoneMasked();
      if (links) links.hidden = !open;
    });
  });

  /* LinkedIn stamp becomes a real link once the URL is configured */
  scope.querySelectorAll("[data-linkedin]").forEach((stamp) => {
    if (!LINKS.linkedin || stamp.tagName === "A") return; // already a real link in the HTML
    const a = document.createElement("a");
    a.className = stamp.className;
    a.href = LINKS.linkedin;
    a.target = "_blank";
    a.rel = "noopener";
    a.innerHTML = stamp.innerHTML;
    a.querySelector(".stamp__ph")?.replaceWith(Object.assign(document.createElement("span"), { className: "stamp__label", textContent: "Connect ↗" }));
    a.setAttribute("aria-label", "LinkedIn profile (opens in a new tab)");
    stamp.replaceWith(a);
  });

  /* optional Behance / Dribbble tags: only when URLs exist */
  const tags = scope.querySelector("[data-profile-tags]");
  if (tags) {
    const items = [
      ["Behance", LINKS.behance],
      ["Dribbble", LINKS.dribbble],
    ].filter(([, url]) => url);
    for (const [label, url] of items) {
      const a = document.createElement("a");
      a.className = "tag-link";
      a.href = url;
      a.target = "_blank";
      a.rel = "noopener";
      a.innerHTML = `${label} <span aria-hidden="true">↗</span><span class="visually-hidden"> (opens in a new tab)</span>`;
      tags.appendChild(a);
    }
    tags.hidden = items.length === 0;
  }

  /* Chennai clock + letter date */
  const clocks = scope.querySelectorAll("[data-chennai-time]");
  if (clocks.length) {
    const f = new Intl.DateTimeFormat("en-GB", { timeZone: "Asia/Kolkata", hour: "2-digit", minute: "2-digit", hour12: false });
    const tick = () => clocks.forEach((c) => (c.textContent = `${f.format(new Date())} IST`));
    tick();
    setInterval(tick, 30000);
  }
  const date = scope.querySelector("[data-letter-date]");
  if (date) {
    date.textContent = `Chennai, ${new Intl.DateTimeFormat("en-GB", { day: "numeric", month: "short", year: "numeric" }).format(new Date())}`;
  }

  initLetter(scope.querySelector("[data-letter]"), addr);
}

/* ---------- the letter ---------- */
function initLetter(form, addr) {
  if (!form) return;
  const fields = {
    message: form.querySelector("#letter-message"),
    name: form.querySelector("#letter-name"),
    email: form.querySelector("#letter-email"),
  };
  const rules = {
    message: (v) => (v.trim().length >= 10 ? "" : "Write at least a sentence (10+ characters) so I know how to help."),
    name: (v) => (v.trim() ? "" : "Add your name so I know who’s writing."),
    email: (v) => (EMAIL_RE.test(v.trim()) ? "" : "Add an email I can reply to, like name@site.com."),
  };
  let attempted = false;

  const check = (key) => {
    const input = fields[key];
    const msg = form.querySelector(`[data-msg-for="${input.id}"]`);
    const error = rules[key](input.value);
    input.setAttribute("aria-invalid", error ? "true" : "false");
    msg.textContent = error;
    msg.className = `field__msg${error ? " is-error" : ""}`;
    return !error;
  };

  for (const key of Object.keys(fields)) {
    fields[key].addEventListener("input", () => attempted && check(key));
    fields[key].addEventListener("blur", () => attempted && check(key));
  }

  form.addEventListener("submit", (e) => {
    e.preventDefault();
    attempted = true;
    const results = Object.keys(fields).map((k) => [k, check(k)]);
    const firstBad = results.find(([, ok]) => !ok);
    if (firstBad) {
      fields[firstBad[0]].focus();
      const n = results.filter(([, ok]) => !ok).length;
      toast(`${n === 1 ? "One thing" : `${n} things`} to fix before the letter can go.`, { emoji: "✏️" });
      return;
    }
    const name = fields.name.value.trim();
    const body = `Dear Jana,\n\n${fields.message.value.trim()}\n\nYours,\n${name}\n${fields.email.value.trim()}`;
    const href = `mailto:${addr}?subject=${encodeURIComponent(`Hello from ${name}`)}&body=${encodeURIComponent(body)}`;
    form.classList.remove("is-sent");
    void form.offsetWidth;
    form.classList.add("is-sent");
    window.location.href = href;
    toast("Your mail app should open with the letter ready. If not, copy my address.", { emoji: "💌", duration: 5000 });
  });
}
