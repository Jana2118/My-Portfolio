/* ==========================================================================
   sky.js — interactive sky. Drag the sun or moon along the arc (mouse, pen,
   touch) or use the range input. Writes the sky palette into CSS custom
   properties and keeps hero text at AA contrast for every minute of the day.
   ========================================================================== */
import { getState, setMinutes, commit, resetToLive, subscribe } from "./time-state.js";
import { sampleSky, pickText, phaseOf, fmt } from "./sky-palette.js";

const DAY_START = 360; // 06:00 — sun on the left horizon
const NIGHT_START = 1080; // 18:00 — moon on the left horizon
const SPAN = 720;
const MID_STOP = 0.55;
const reduceMotion = matchMedia("(prefers-reduced-motion: reduce)");

export function initSky(el) {
  const root = document.documentElement;
  const air = el.querySelector(".sky__air");
  const orbit = el.querySelector("[data-sky-orbit]");
  const path = orbit?.querySelector("[data-sky-path]");
  const bodies = {
    sun: orbit?.querySelector('[data-body="sun"]'),
    moon: orbit?.querySelector('[data-body="moon"]'),
  };
  const copy = el.querySelector("[data-sky-copy]");
  const range = el.querySelector("[data-sky-range]");
  const out = {
    time: el.querySelector("[data-sky-time]"),
    weather: el.querySelector("[data-sky-weather]"),
    icon: el.querySelector("[data-sky-icon]"),
    hint: el.querySelector("[data-sky-hint]"),
    hintWrap: el.querySelector("[data-sky-hint-wrap]"),
    now: el.querySelector("[data-sky-now]"),
  };

  let geo = { w: 0, h: 0, rx: 0, ry: 0, size: 0 };
  let region = { f0: 0.2, f1: 0.8 };
  const textCache = new Map();
  let raf = 0;
  let pending = null;
  let intro = null; // { which, minutes } while the sunrise intro plays

  makeStars(el.querySelector("[data-sky-stars]"));
  // mark the intro before the first render so nothing eases or flashes into place
  if (!reduceMotion.matches && orbit) el.classList.add("is-intro");

  /* ---------- geometry ---------- */
  function measure() {
    if (orbit) {
      const r = orbit.getBoundingClientRect();
      const size = bodies.sun?.offsetWidth || 72;
      geo = { w: r.width, h: r.height, size, rx: r.width / 2 - size / 2, ry: r.height - size / 2 };
      if (path) {
        const svg = path.ownerSVGElement;
        svg.setAttribute("viewBox", `0 0 ${r.width} ${r.height}`);
        const cx = r.width / 2;
        path.setAttribute("d", `M ${cx - geo.rx} ${r.height} A ${geo.rx} ${geo.ry} 0 0 1 ${cx + geo.rx} ${r.height}`);
      }
    }
    if (copy && air) {
      const a = air.getBoundingClientRect();
      const c = copy.getBoundingClientRect();
      const f0 = Math.max(0, (c.top - a.top) / a.height);
      const f1 = Math.min(1, (c.bottom - a.top) / a.height);
      const key = `${f0.toFixed(2)}-${f1.toFixed(2)}`;
      if (key !== region.key) textCache.clear();
      region = { f0, f1, key };
      // where the copy sits, so the star field can fade out behind it
      el.style.setProperty("--copy-cx", `${(c.left + c.width / 2 - a.left).toFixed(0)}px`);
      el.style.setProperty("--copy-cy", `${(c.top + c.height / 2 - a.top).toFixed(0)}px`);
      el.style.setProperty("--copy-rx", `${(c.width * 0.62).toFixed(0)}px`);
      el.style.setProperty("--copy-ry", `${(c.height * 0.66).toFixed(0)}px`);
    }
  }

  /* ---------- render ---------- */
  /* arc position for p (0 = left horizon, 1 = right horizon) without styling */
  function arc(p) {
    const theta = Math.PI * (1 - p);
    return {
      visible: p > -0.09 && p < 1.09,
      x: geo.w / 2 + geo.rx * Math.cos(theta),
      y: geo.h - geo.ry * Math.sin(theta),
      cos: Math.cos(theta),
      sin: Math.sin(theta),
    };
  }

  function placeBody(body, p) {
    if (!body) return { visible: false, x: 0, y: 0 };
    const theta = Math.PI * (1 - p);
    const x = geo.w / 2 + geo.rx * Math.cos(theta);
    const y = geo.h - geo.ry * Math.sin(theta);
    const visible = p > -0.09 && p < 1.09;
    body.style.setProperty("--x", `${(x - geo.size / 2).toFixed(1)}px`);
    body.style.setProperty("--y", `${(y - geo.size / 2).toFixed(1)}px`);
    body.classList.toggle("is-set", !visible);
    return { visible, x, y, cos: Math.cos(theta), sin: Math.sin(theta) };
  }

  /* The "Drag the sun" note sits beside whichever body is up: above it when
     it's low, below it when it's high, flipped inward near the edges. */
  function placeHint(b) {
    const h = out.hintWrap;
    if (!h) return;
    const gap = geo.size / 2 + 14;
    const low = b.y > geo.h * 0.45;
    const hy = low ? b.y - gap - h.offsetHeight : b.y + gap;
    const half = h.offsetWidth / 2;
    const hx = Math.min(geo.w - half, Math.max(half, b.x));
    h.style.setProperty("--hx", `${(hx - half).toFixed(1)}px`);
    h.style.setProperty("--hy", `${hy.toFixed(1)}px`);
  }

  function render({ minutes, mode }) {
    const sky = sampleSky(minutes);
    const key = Math.round(minutes);
    let text = textCache.get(key);
    if (!text) {
      text = pickText(sky, { f0: region.f0, f1: region.f1, midStop: MID_STOP });
      textCache.set(key, text);
    }

    const s = el.style;
    s.setProperty("--sky-top", sky.top);
    s.setProperty("--sky-mid", sky.mid);
    s.setProperty("--sky-bottom", sky.bottom);
    s.setProperty("--hill-1", sky.hill1);
    s.setProperty("--hill-2", sky.hill2);
    s.setProperty("--hill-3", sky.hill3);
    s.setProperty("--sea", sky.sea);
    s.setProperty("--cloud", sky.cloud);
    s.setProperty("--star-alpha", sky.star.toFixed(3));
    s.setProperty("--day-alpha", (1 - sky.star).toFixed(3));
    if (text) {
      s.setProperty("--sky-text", text.text);
      s.setProperty("--sky-text-2", text.text2);
      s.setProperty("--sky-accent", text.accent);
      s.setProperty("--haze", text.haze);
      s.setProperty("--haze-a", String(text.hazeAlpha));
      el.dataset.scheme = text.scheme;
    }

    const sunP = (minutes - DAY_START) / SPAN;
    const moonP = (((minutes - NIGHT_START) % 1440) + 1440) % 1440 / SPAN;
    // while the intro plays, its body is moved by the intro, not here
    const pos = (body, p) => (intro && body === bodies[intro.which] ? arc(p) : placeBody(body, p));
    const sun = pos(bodies.sun, sunP > 1.5 ? sunP - 2 : sunP);
    const moon = pos(bodies.moon, moonP > 1.5 ? moonP - 2 : moonP);
    const isDay = minutes >= DAY_START && minutes < NIGHT_START;
    const light = isDay ? sun : moon;
    if (!intro) placeHint(light);
    root.style.setProperty("--light-x", (light.cos * (isDay ? 1 : 0.5)).toFixed(3));
    root.style.setProperty("--light-y", Math.max(0, light.sin).toFixed(3));

    const ph = phaseOf(minutes);
    const t = fmt(minutes);
    if (out.time) {
      out.time.textContent = t;
      out.time.dateTime = t;
    }
    if (out.weather) out.weather.textContent = ph.weather;
    if (out.icon) out.icon.textContent = ph.icon;
    if (out.hint) out.hint.textContent = isDay ? "Drag the sun" : "Drag the moon";
    if (out.now) out.now.hidden = mode === "live";
    if (range && document.activeElement !== range) range.value = String(Math.round(minutes));
    if (range) range.setAttribute("aria-valuetext", `${t}, ${ph.phase}${mode === "live" ? " (your local time)" : ""}`);
    el.classList.toggle("is-night", !isDay);
  }

  function schedule(state) {
    if (intro && Math.round(state.minutes) !== intro.minutes) stopIntro();
    pending = state;
    if (raf) return;
    raf = requestAnimationFrame(() => {
      raf = 0;
      render(pending);
    });
  }

  /* ---------- dragging ---------- */
  function minutesFromPointer(e, which) {
    const r = orbit.getBoundingClientRect();
    const dx = (e.clientX - (r.left + r.width / 2)) / geo.rx;
    const dy = (r.top + r.height - e.clientY) / geo.ry;
    let theta = Math.atan2(Math.max(dy, -0.25), dx);
    if (dy < 0 && dx < 0 && theta < 0) theta += 2 * Math.PI; // left side, below horizon
    theta = Math.min(Math.PI + 0.25, Math.max(-0.25, theta));
    const p = 1 - theta / Math.PI;
    return (which === "sun" ? DAY_START : NIGHT_START) + p * SPAN;
  }

  for (const [which, body] of Object.entries(bodies)) {
    if (!body) continue;
    body.addEventListener("pointerdown", (e) => {
      if (intro) stopIntro();
      if (body.classList.contains("is-set") || (e.pointerType === "mouse" && e.button !== 0)) return;
      e.preventDefault();
      body.setPointerCapture(e.pointerId);
      el.classList.add("is-dragging");
      body.classList.add("is-grabbed");
      const move = (ev) => setMinutes(minutesFromPointer(ev, which), { persist: false });
      const up = () => {
        el.classList.remove("is-dragging");
        body.classList.remove("is-grabbed");
        body.removeEventListener("pointermove", move);
        body.removeEventListener("pointerup", up);
        body.removeEventListener("pointercancel", up);
        commit();
        el.classList.add("has-dragged");
      };
      body.addEventListener("pointermove", move);
      body.addEventListener("pointerup", up);
      body.addEventListener("pointercancel", up);
    });
  }

  /* ---------- keyboard / slider ---------- */
  if (range) {
    range.addEventListener("input", () => setMinutes(Number(range.value), { persist: false }));
    range.addEventListener("change", () => commit());
    range.addEventListener("keydown", (e) => {
      const steps = { ArrowRight: 15, ArrowUp: 15, ArrowLeft: -15, ArrowDown: -15, PageUp: 60, PageDown: -60 };
      if (!(e.key in steps)) return;
      e.preventDefault();
      const delta = steps[e.key] * (e.shiftKey && Math.abs(steps[e.key]) === 15 ? 4 : 1);
      const next = Math.round((getState().minutes + delta) / 5) * 5;
      setMinutes((next + 1440) % 1440);
      range.value = String(getState().minutes);
    });
  }
  out.now?.addEventListener("click", () => {
    resetToLive();
    range?.focus();
  });

  /* ---------- sunrise intro: the active body rises to the current time ---------- */
  function playIntro() {
    if (reduceMotion.matches || !orbit) return el.classList.remove("is-intro");
    const { minutes } = getState();
    const isDay = minutes >= DAY_START && minutes < NIGHT_START;
    const which = isDay ? "sun" : "moon";
    const body = bodies[which];
    if (!body) return;
    const target = isDay ? (minutes - DAY_START) / SPAN : ((((minutes - NIGHT_START) % 1440) + 1440) % 1440) / SPAN;
    const from = -0.12;
    intro = { which, minutes: Math.round(minutes) };
    el.classList.add("is-intro");
    placeBody(body, from);
    const t0 = performance.now() + 250;
    const dur = 1800;
    const step = (now) => {
      if (!intro) return;
      const t = Math.max(0, Math.min(1, (now - t0) / dur));
      const e = 1 - Math.pow(1 - t, 3);
      placeBody(body, from + (target - from) * e);
      if (t < 1) requestAnimationFrame(step);
      else stopIntro();
    };
    requestAnimationFrame(step);
  }
  function stopIntro() {
    if (!intro) return;
    intro = null;
    el.classList.remove("is-intro");
    measure(); // the copy has finished its entrance; re-measure for contrast
    render(getState());
  }

  /* ---------- lifecycle ---------- */
  measure();
  const ro = new ResizeObserver(() => {
    measure();
    render(getState());
  });
  ro.observe(el);
  if (copy) ro.observe(copy);
  subscribe(schedule);
  render(getState());
  el.classList.add("is-ready");
  playIntro();
}

/* Deterministic star field (decorative). */
function makeStars(svg) {
  if (!svg) return;
  const NS = "http://www.w3.org/2000/svg";
  let seed = 7;
  const rnd = () => ((seed = (seed * 16807) % 2147483647) / 2147483647);
  for (let i = 0; i < 70; i++) {
    const c = document.createElementNS(NS, "circle");
    c.setAttribute("cx", (rnd() * 100).toFixed(2));
    c.setAttribute("cy", (rnd() * 62).toFixed(2));
    c.setAttribute("r", (rnd() * 0.16 + 0.06).toFixed(2));
    if (i % 4 === 0) c.classList.add("twinkle");
    c.style.animationDelay = `${(rnd() * 4).toFixed(2)}s`;
    svg.appendChild(c);
  }
}
