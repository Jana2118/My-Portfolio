/* motion.js — decorative motion that needs a little JS: word-rise headings
   (+ hand-drawn underline), count-up numbers, card tilt + spotlight, the desk
   landing and the nav sun that turns as you scroll. Does nothing when the
   visitor prefers reduced motion, so every element keeps its resting state. */
const reduce = matchMedia("(prefers-reduced-motion: reduce)");
const finePointer = matchMedia("(hover: hover) and (pointer: fine)");
const NS = "http://www.w3.org/2000/svg";

export function initMotion() {
  if (reduce.matches) return;
  document.documentElement.classList.add("motion-on");
  splitHeadings();
  countUps();
  tiltCards();
  deskLanding();
  navSpin();
}

/* ---------- word-rise headings ---------- */
function wrap(node, i) {
  const s = document.createElement("span");
  s.className = "w";
  s.style.setProperty("--i", String(i));
  s.append(node);
  return s;
}

function splitHeadings() {
  const heads = [...document.querySelectorAll("[data-split]")];
  for (const h of heads) {
    const frag = document.createDocumentFragment();
    let i = 0;
    for (const node of [...h.childNodes]) {
      if (node.nodeType === Node.TEXT_NODE) {
        for (const part of node.textContent.split(/(\s+)/)) {
          if (!part) continue;
          if (/^\s+$/.test(part)) frag.append(part);
          else frag.append(wrap(document.createTextNode(part), i++));
        }
      } else {
        frag.append(wrap(node, i++));
      }
    }
    h.replaceChildren(frag);
    // section headings get a hand-drawn underline under the italic word
    if (h.dataset.split !== "load") {
      const accent = h.querySelector(".accent");
      if (accent && !accent.querySelector(".squig")) {
        const svg = document.createElementNS(NS, "svg");
        svg.setAttribute("class", "squig");
        svg.setAttribute("viewBox", "0 0 120 12");
        svg.setAttribute("preserveAspectRatio", "none");
        svg.setAttribute("aria-hidden", "true");
        svg.setAttribute("focusable", "false");
        const path = document.createElementNS(NS, "path");
        path.setAttribute("d", "M2 7 Q 12 2 22 7 T 42 7 T 62 7 T 82 7 T 102 7 T 118 6");
        path.setAttribute("pathLength", "1");
        svg.append(path);
        accent.append(svg);
      }
    }
  }
  // hero titles rise on load; section headings when they scroll into view
  const onLoad = heads.filter((h) => h.dataset.split === "load");
  requestAnimationFrame(() => requestAnimationFrame(() => onLoad.forEach((h) => h.classList.add("is-in"))));
  const later = heads.filter((h) => h.dataset.split !== "load");
  if (!("IntersectionObserver" in window)) return later.forEach((h) => h.classList.add("is-in"));
  const io = new IntersectionObserver(
    (entries) => {
      for (const e of entries) {
        if (!e.isIntersecting) continue;
        e.target.classList.add("is-in");
        io.unobserve(e.target);
      }
    },
    { rootMargin: "0px 0px -12% 0px" }
  );
  later.forEach((h) => io.observe(h));
}

/* ---------- count-up numbers (final value is in the DOM at rest) ---------- */
function countUps() {
  const nums = [...document.querySelectorAll(".stat__num, .stat-card__num")];
  const targets = [];
  for (const el of nums) {
    const walker = document.createTreeWalker(el, NodeFilter.SHOW_TEXT);
    let node;
    let hit = null;
    while ((node = walker.nextNode())) {
      if (node.parentElement.closest(".visually-hidden, [aria-hidden='true']")) continue;
      if (/\d/.test(node.textContent)) hit = node;
    }
    if (!hit) continue;
    const m = hit.textContent.match(/^(.*?)(\d+)(.*)$/);
    if (!m) continue;
    const [, before, digits, after] = m;
    // the digits stay real text (copyable, read correctly); only they animate
    const vis = document.createElement("span");
    vis.className = "count";
    vis.textContent = digits;
    hit.replaceWith(before, vis, after);
    targets.push({ el, vis, n: Number(digits) });
  }
  if (!targets.length || !("IntersectionObserver" in window)) return;
  const run = ({ vis, n }) => {
    const t0 = performance.now();
    const dur = 1100 + Math.min(n, 40) * 12;
    const step = (now) => {
      const t = Math.min(1, (now - t0) / dur);
      const e = 1 - Math.pow(1 - t, 4);
      vis.textContent = String(Math.round(n * e));
      if (t < 1) requestAnimationFrame(step);
    };
    vis.textContent = "0";
    requestAnimationFrame(step);
  };
  const io = new IntersectionObserver(
    (entries) => {
      for (const e of entries) {
        if (!e.isIntersecting) continue;
        const t = targets.find((x) => x.el === e.target);
        if (t) run(t);
        io.unobserve(e.target);
      }
    },
    { threshold: 0.6 }
  );
  targets.forEach((t) => io.observe(t.el));
}

/* ---------- work cards: gentle tilt toward the pointer + spotlight ---------- */
function tiltCards() {
  if (!finePointer.matches) return;
  for (const card of document.querySelectorAll(".card")) {
    let raf = 0;
    card.addEventListener("pointermove", (e) => {
      if (raf) return;
      raf = requestAnimationFrame(() => {
        raf = 0;
        const r = card.getBoundingClientRect();
        const x = e.clientX - r.left;
        const y = e.clientY - r.top;
        const px = x / r.width - 0.5;
        const py = y / r.height - 0.5;
        card.style.setProperty("--rx", `${(px * 4).toFixed(2)}deg`);
        card.style.setProperty("--ry", `${(-py * 4).toFixed(2)}deg`);
        card.style.setProperty("--mx", `${x.toFixed(0)}px`);
        card.style.setProperty("--my", `${y.toFixed(0)}px`);
        card.classList.add("is-tilting");
      });
    });
    card.addEventListener("pointerleave", () => {
      card.style.setProperty("--rx", "0deg");
      card.style.setProperty("--ry", "0deg");
      card.classList.remove("is-tilting");
    });
  }
}

/* ---------- desk: objects drop onto it the first time it's seen ---------- */
function deskLanding() {
  const desk = document.querySelector("[data-desk]");
  if (!desk || !("IntersectionObserver" in window)) return;
  desk.querySelectorAll(".obj").forEach((o, i) => o.style.setProperty("--i", String(i)));
  desk.classList.add("will-land");
  const io = new IntersectionObserver(
    (entries) => {
      if (!entries.some((e) => e.isIntersecting)) return;
      desk.classList.add("has-landed");
      desk.classList.remove("will-land");
      io.disconnect();
    },
    { threshold: 0.18 }
  );
  io.observe(desk);
}

/* ---------- the nav sun turns as you scroll ---------- */
function navSpin() {
  const nav = document.querySelector("[data-nav]");
  if (!nav) return;
  let raf = 0;
  addEventListener(
    "scroll",
    () => {
      if (raf) return;
      raf = requestAnimationFrame(() => {
        raf = 0;
        nav.style.setProperty("--spin", `${(scrollY * 0.18) % 360}deg`);
      });
    },
    { passive: true }
  );
}
