/* about.js — the About band's playful bits (styles in css/about.css).
   · Designer ↔ Developer switch: flips the card, changes the accent word into
     code, and turns the paper into a code grid. "Inspect" / "Run" on the card
     do the same. The hidden face is inert, so Tab only reaches what you see.
   · The code side types itself out the first time it's shown.
   · Doodles and the flow sketch draw in when the section arrives; doodles
     drift a little with the pointer; the card tilts toward it.
   · Skill stickers can be dragged (pointer or arrow keys) and put back
     (double-click or Escape).
   Under prefers-reduced-motion: no typing, drawing, drifting or tilting;
   the switch and stickers still work, instantly. */
import { toast } from "./toast.js";

const reduce = matchMedia("(prefers-reduced-motion: reduce)");
const finePointer = matchMedia("(pointer: fine)");

export function initAbout(section) {
  const flip = section.querySelector("[data-flip]");
  const faces = { design: section.querySelector('[data-face="design"]'), dev: section.querySelector('[data-face="dev"]') };
  const word = section.querySelector(".about__word");
  const modeBtns = [...section.querySelectorAll("[data-mode-btn]")];
  const code = section.querySelector("[data-type]");
  let typed = false;
  const phrases = [...section.querySelectorAll(".phrase")];

  // ---- phrasebook: each card flips between its design and code name ----
  phrases.forEach((b) =>
    b.addEventListener("click", () => b.setAttribute("aria-pressed", String(b.getAttribute("aria-pressed") !== "true")))
  );

  // ---- summary: wrap words so they can light up as the reader scrolls ----
  const summary = section.querySelector(".about__summary");
  if (summary && !summary.querySelector(".w") && summary.children.length === 0) {
    const words = summary.textContent.trim().split(/\s+/);
    summary.innerHTML = words.map((w) => `<span class="w">${w.replace(/&/g, "&amp;").replace(/</g, "&lt;")}</span>`).join(" ");
  }

  // ---- magnetic switch: leans a few pixels toward the pointer ----
  const sw = section.querySelector(".about__switch");
  if (sw && !reduce.matches && finePointer.matches) {
    sw.style.transition = "translate 380ms cubic-bezier(.34,1.56,.64,1)";
    sw.addEventListener("pointermove", (e) => {
      const r = sw.getBoundingClientRect();
      const x = ((e.clientX - r.left) / r.width - 0.5) * 8;
      const y = ((e.clientY - r.top) / r.height - 0.5) * 6;
      sw.style.translate = `${x.toFixed(1)}px ${y.toFixed(1)}px`;
    });
    sw.addEventListener("pointerleave", () => (sw.style.translate = "0 0"));
  }

  // ---- draw-in setup ----
  section.querySelectorAll(".doodle, .about__arrow path, .board__flow .sketch path").forEach((el) => {
    if (el.tagName === "path" || el.tagName === "circle") el.setAttribute("pathLength", "1");
  });
  if (!reduce.matches && "IntersectionObserver" in window) {
    section.classList.add("is-animated");
    const io = new IntersectionObserver(
      ([e]) => {
        if (!e.isIntersecting) return;
        section.classList.add("is-drawn");
        io.disconnect();
      },
      { threshold: 0.2 }
    );
    io.observe(section);
  } else {
    section.classList.add("is-drawn");
  }

  // ---- mode switch / flip ----
  function setMode(mode, { from } = {}) {
    if (section.dataset.mode === mode) return;
    section.dataset.mode = mode;
    // phrasebook cards follow the mode again (their own flips reset)
    phrases.forEach((b) => b.setAttribute("aria-pressed", "false"));
    modeBtns.forEach((b) => b.setAttribute("aria-pressed", String(b.dataset.modeBtn === mode)));
    for (const [key, face] of Object.entries(faces)) {
      const hidden = key !== mode;
      face.inert = hidden;
      face.setAttribute("aria-hidden", String(hidden));
    }
    if (!reduce.matches && word) {
      word.classList.remove("is-swapping");
      void word.offsetWidth;
      word.classList.add("is-swapping");
    }
    if (mode === "dev" && !typed) typeCode();
    if (from === "card") {
      // keep focus on the card's button of the face that just turned up
      faces[mode].querySelector(".flip__btn")?.focus({ preventScroll: true });
    }
    if (mode === "design" && from === "card") toast("Rendered. Code in, design out.", { emoji: "✨" });
  }
  faces.dev.inert = true;
  faces.dev.setAttribute("aria-hidden", "true");
  modeBtns.forEach((b) => b.addEventListener("click", () => setMode(b.dataset.modeBtn)));
  section.querySelectorAll("[data-flip-to]").forEach((b) => b.addEventListener("click", () => setMode(b.dataset.flipTo, { from: "card" })));
  word?.addEventListener("animationend", () => word.classList.remove("is-swapping"));

  // ---- typewriter (first time the code side shows) ----
  function typeCode() {
    typed = true;
    if (!code || reduce.matches) return;
    const nodes = [];
    const walker = document.createTreeWalker(code, NodeFilter.SHOW_TEXT);
    while (walker.nextNode()) nodes.push([walker.currentNode, walker.currentNode.nodeValue]);
    nodes.forEach(([n]) => (n.nodeValue = ""));
    const caret = document.createElement("span");
    caret.className = "caret";
    caret.setAttribute("aria-hidden", "true");
    code.append(caret);
    const total = nodes.reduce((a, [, t]) => a + t.length, 0);
    const start = performance.now() + 450; // let the flip land first
    const dur = 1500;
    const tick = (now) => {
      const shown = Math.max(0, Math.min(total, Math.round(((now - start) / dur) * total)));
      let left = shown;
      for (const [n, t] of nodes) {
        const k = Math.min(t.length, left);
        if (n.nodeValue.length !== k) n.nodeValue = t.slice(0, k);
        left -= k;
      }
      if (shown < total) requestAnimationFrame(tick);
    };
    requestAnimationFrame(tick);
  }

  // ---- pointer: doodles drift, card tilts ----
  if (!reduce.matches && finePointer.matches) {
    const doodles = section.querySelector(".about__doodles");
    let raf = 0;
    section.addEventListener("pointermove", (e) => {
      if (raf) return;
      raf = requestAnimationFrame(() => {
        raf = 0;
        const r = section.getBoundingClientRect();
        doodles?.style.setProperty("--px", ((e.clientX - r.left) / r.width - 0.5).toFixed(3));
        doodles?.style.setProperty("--py", ((e.clientY - r.top) / r.height - 0.5).toFixed(3));
      });
    });
    const card = section.querySelector(".about__card");
    card?.addEventListener("pointermove", (e) => {
      const r = card.getBoundingClientRect();
      flip.style.setProperty("--rx", `${(((e.clientX - r.left) / r.width - 0.5) * 8).toFixed(2)}deg`);
      flip.style.setProperty("--ry", `${(-((e.clientY - r.top) / r.height - 0.5) * 6).toFixed(2)}deg`);
    });
    card?.addEventListener("pointerleave", () => {
      flip.style.setProperty("--rx", "0deg");
      flip.style.setProperty("--ry", "0deg");
    });
  }

  // ---- stickers ----
  for (const s of section.querySelectorAll(".skill-sticker")) initSticker(s, section);
}

function initSticker(el, bounds) {
  let x = 0;
  let y = 0;
  let drag = null;
  let moved = false;
  const apply = () => {
    el.style.setProperty("--x", `${x}px`);
    el.style.setProperty("--y", `${y}px`);
    el.classList.toggle("is-moved", x !== 0 || y !== 0);
  };
  const clamp = (nx, ny) => {
    // keep the sticker inside the About band
    const b = bounds.getBoundingClientRect();
    const r = el.getBoundingClientRect();
    const baseL = r.left - x;
    const baseT = r.top - y;
    return [
      Math.max(b.left + 8 - baseL, Math.min(b.right - 8 - r.width - baseL, nx)),
      Math.max(b.top + 8 - baseT, Math.min(b.bottom - 8 - r.height - baseT, ny)),
    ];
  };
  const slap = () => {
    el.classList.remove("is-stuck");
    void el.offsetWidth;
    el.classList.add("is-stuck");
  };
  const reset = () => {
    x = 0;
    y = 0;
    apply();
    slap();
  };

  el.addEventListener("pointerdown", (e) => {
    if (e.button !== 0) return;
    drag = { sx: e.clientX - x, sy: e.clientY - y, moved: false };
    el.setPointerCapture(e.pointerId);
  });
  el.addEventListener("pointermove", (e) => {
    if (!drag) return;
    const nx = e.clientX - drag.sx;
    const ny = e.clientY - drag.sy;
    if (!drag.moved && Math.hypot(nx - x, ny - y) < 5) return;
    drag.moved = true;
    el.classList.add("is-dragging");
    [x, y] = clamp(nx, ny);
    apply();
  });
  const end = () => {
    if (!drag) return;
    moved = drag.moved;
    drag = null;
    el.classList.remove("is-dragging");
    if (moved) slap();
  };
  el.addEventListener("pointerup", end);
  el.addEventListener("pointercancel", end);
  el.addEventListener("click", (e) => {
    if (moved) {
      moved = false;
      e.preventDefault();
      return;
    }
    slap();
  });
  el.addEventListener("dblclick", reset);
  el.addEventListener("keydown", (e) => {
    const step = e.shiftKey ? 36 : 12;
    const keys = { ArrowLeft: [-step, 0], ArrowRight: [step, 0], ArrowUp: [0, -step], ArrowDown: [0, step] };
    if (keys[e.key]) {
      e.preventDefault();
      [x, y] = clamp(x + keys[e.key][0], y + keys[e.key][1]);
      apply();
    } else if (e.key === "Escape" && (x || y)) {
      e.preventDefault();
      reset();
    }
  });
}
