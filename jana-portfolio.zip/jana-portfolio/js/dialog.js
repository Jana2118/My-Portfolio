/* dialog.js — native <dialog> modals: Esc closes, page is inert while open
   (focus is trapped by the browser), click on the backdrop closes, and focus
   returns to whatever opened it. Adds .is-closing for exit animations. */
const reduce = matchMedia("(prefers-reduced-motion: reduce)");
const returnTo = new WeakMap();

export function openDialog(dialog, trigger = document.activeElement) {
  if (!dialog || dialog.open) return;
  returnTo.set(dialog, trigger);
  dialog.classList.remove("is-closing");
  dialog.showModal();
  document.documentElement.classList.add("has-dialog");
  const first = dialog.querySelector("[autofocus]") || dialog.querySelector("[data-dialog-focus]");
  first?.focus();
  dialog.dispatchEvent(new CustomEvent("dialog:open"));
}

export function closeDialog(dialog) {
  if (!dialog || !dialog.open || dialog.classList.contains("is-closing")) return;
  const finish = () => {
    dialog.classList.remove("is-closing");
    dialog.close();
  };
  if (reduce.matches) return finish();
  dialog.classList.add("is-closing");
  let done = false;
  const once = () => {
    if (done) return;
    done = true;
    finish();
  };
  dialog.addEventListener("animationend", once, { once: true });
  setTimeout(once, 450);
}

/** Wire every dialog on the page once. */
export function initDialogs(scope = document) {
  for (const dialog of scope.querySelectorAll("dialog[data-dialog]")) {
    if (dialog.dataset.wired) continue;
    dialog.dataset.wired = "1";
    dialog.addEventListener("cancel", (e) => {
      e.preventDefault(); // run our exit animation instead of the instant close
      closeDialog(dialog);
    });
    dialog.addEventListener("close", () => {
      document.documentElement.classList.toggle("has-dialog", !!document.querySelector("dialog[open]"));
      const t = returnTo.get(dialog);
      if (t && typeof t.focus === "function") t.focus({ preventScroll: true });
      dialog.dispatchEvent(new CustomEvent("dialog:closed"));
    });
    dialog.addEventListener("click", (e) => {
      if (e.target === dialog) closeDialog(dialog); // backdrop
    });
    for (const btn of dialog.querySelectorAll("[data-dialog-close]")) {
      btn.addEventListener("click", () => closeDialog(dialog));
    }
  }
  for (const trigger of scope.querySelectorAll("[data-dialog-open]")) {
    if (trigger.dataset.wired) continue;
    trigger.dataset.wired = "1";
    trigger.addEventListener("click", (e) => {
      if (trigger.dataset.dragged === "1") return; // desk drag, not a click
      e.preventDefault();
      openDialog(document.getElementById(trigger.dataset.dialogOpen), trigger);
    });
  }
}
