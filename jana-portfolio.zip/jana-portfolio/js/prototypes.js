/* prototypes.js — interactive recreations on the case-study pages.
   Illustrative data only; every state change is announced politely. */
const reduce = matchMedia("(prefers-reduced-motion: reduce)");

export function initPrototypes(scope = document) {
  scope.querySelectorAll('[data-proto="ota"]').forEach(initOta);
  scope.querySelectorAll('[data-proto="share"]').forEach(initShare);
  scope.querySelectorAll('[data-proto="accident"]').forEach(initAccident);
  initToc();
}

const say = (root, msg) => {
  const live = root.querySelector("[data-live]");
  if (!live) return;
  live.textContent = "";
  requestAnimationFrame(() => (live.textContent = msg));
};

/* ---------- OTA rollout ---------- */
function initOta(root) {
  const rows = [...root.querySelectorAll("tr[data-device]")];
  const start = root.querySelector("[data-ota-start]");
  const reset = root.querySelector("[data-ota-reset]");
  const summary = root.querySelector("[data-summary]");
  const FROM = "v2.4.1";
  const TO = "v2.5.0";
  let timers = [];

  const set = (row, status, p) => {
    const chip = row.querySelector("[data-status]");
    const bar = row.querySelector("[role=progressbar]");
    const fw = row.querySelector("[data-fw]");
    const action = row.querySelector("[data-action]");
    const kinds = { Queued: "", Updating: "chip--info", Retry: "chip--warn", Done: "chip--ok" };
    chip.className = `chip ${kinds[status]}`;
    chip.textContent = status;
    row.dataset.state = status;
    bar.style.setProperty("--p", String(p));
    bar.setAttribute("aria-valuenow", String(Math.round(p * 100)));
    bar.classList.toggle("bar--warn", status === "Retry");
    bar.classList.toggle("bar--ok", status === "Done");
    fw.textContent = status === "Done" ? TO : status === "Queued" ? FROM : `${FROM} → ${TO}`;
    action.innerHTML = "";
    if (status === "Retry") {
      const b = document.createElement("button");
      b.type = "button";
      b.className = "btn btn--ghost btn--small";
      b.textContent = "Retry";
      b.setAttribute("aria-label", `Retry ${row.dataset.device}`);
      b.addEventListener("click", () => {
        run(row, false);
        start.focus();
      });
      action.appendChild(b);
    }
    updateSummary();
  };

  const updateSummary = () => {
    const c = { Queued: 0, Updating: 0, Retry: 0, Done: 0 };
    rows.forEach((r) => c[r.dataset.state || "Queued"]++);
    summary.textContent = `${c.Done} done · ${c.Updating} updating · ${c.Queued} queued · ${c.Retry} to retry`;
  };

  const run = (row, mayFail) => {
    const id = row.dataset.device;
    const fail = mayFail && row.dataset.fail === "true";
    const step = reduce.matches ? 60 : 340;
    let p = 0;
    set(row, "Updating", 0.05);
    const tick = () => {
      p += 0.18;
      if (fail && p > 0.4) {
        set(row, "Retry", 0.4);
        say(root, `${id} update failed. Retry is available.`);
        return;
      }
      if (p >= 1) {
        set(row, "Done", 1);
        say(root, `${id} updated to ${TO}.`);
        if (rows.every((r) => r.dataset.state === "Done")) say(root, `Rollout complete. All devices on ${TO}.`);
        return;
      }
      set(row, "Updating", p);
      timers.push(setTimeout(tick, step));
    };
    timers.push(setTimeout(tick, step));
  };

  start.addEventListener("click", () => {
    const queued = rows.filter((r) => r.dataset.state === "Queued" || !r.dataset.state);
    if (!queued.length) {
      say(root, "Nothing queued. Reset to run the rollout again.");
      return;
    }
    say(root, `Rollout started for ${queued.length} devices.`);
    queued.forEach((r, k) => timers.push(setTimeout(() => run(r, true), k * (reduce.matches ? 80 : 600))));
  });
  reset.addEventListener("click", () => {
    timers.forEach(clearTimeout);
    timers = [];
    rows.forEach((r) => set(r, "Queued", 0));
    say(root, "Rollout reset. All devices queued.");
  });
  rows.forEach((r) => set(r, "Queued", 0));
}

/* ---------- permission sharing ---------- */
function initShare(root) {
  const rows = [...root.querySelectorAll("tr[data-request]")];
  const summary = root.querySelector("[data-summary]");
  const kinds = { Pending: "", Active: "chip--ok", Revoked: "chip--hot" };

  const render = (row) => {
    const state = row.dataset.state;
    const chip = row.querySelector("[data-status]");
    const btn = row.querySelector("[data-act]");
    const sel = row.querySelector("select");
    const who = row.dataset.request;
    chip.className = `chip ${kinds[state]}`;
    chip.textContent = state;
    btn.textContent = state === "Active" ? "Revoke" : "Approve";
    btn.className = `btn btn--small ${state === "Active" ? "btn--ghost" : "btn--accent"}`;
    btn.setAttribute("aria-label", `${btn.textContent} ${who}`);
    sel.disabled = state === "Active";
  };
  const updateSummary = () => {
    const c = { Pending: 0, Active: 0, Revoked: 0 };
    rows.forEach((r) => c[r.dataset.state]++);
    summary.textContent = `${c.Pending} pending · ${c.Active} active · ${c.Revoked} revoked`;
  };
  rows.forEach((row) => {
    const btn = row.querySelector("[data-act]");
    const sel = row.querySelector("select");
    btn.addEventListener("click", () => {
      const who = row.dataset.request;
      if (row.dataset.state === "Active") {
        row.dataset.state = "Revoked";
        say(root, `Access revoked for ${who}.`);
      } else {
        row.dataset.state = "Active";
        say(root, `${who} approved for ${sel.options[sel.selectedIndex].text}.`);
      }
      render(row);
      updateSummary();
    });
    render(row);
  });
  updateSummary();
}

/* ---------- accident alert flow ---------- */
function initAccident(root) {
  const screens = [...root.querySelectorAll("[data-screen]")];
  const go = (name) => {
    screens.forEach((s) => s.classList.toggle("is-on", s.dataset.screen === name));
    const title = root.querySelector(`[data-screen="${name}"] .mock-phone__title`);
    title?.focus();
    say(root, title?.textContent || "");
  };
  root.querySelectorAll("[data-go]").forEach((b) => b.addEventListener("click", () => go(b.dataset.go)));
}

/* ---------- sticky contents: highlight the section in view ---------- */
function initToc() {
  const links = [...document.querySelectorAll(".cs-toc a")];
  if (!links.length || !("IntersectionObserver" in window)) return;
  const map = new Map(links.map((a) => [a.hash.slice(1), a]));
  const io = new IntersectionObserver(
    (entries) => {
      for (const e of entries) {
        if (!e.isIntersecting) continue;
        links.forEach((l) => l.removeAttribute("aria-current"));
        map.get(e.target.id)?.setAttribute("aria-current", "true");
      }
    },
    { rootMargin: "-30% 0px -60% 0px" }
  );
  map.forEach((_, id) => {
    const el = document.getElementById(id);
    if (el) io.observe(el);
  });
}
