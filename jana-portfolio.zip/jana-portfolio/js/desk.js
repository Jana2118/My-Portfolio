/* desk.js — the tactile desk: random tilt per visit, drag objects around
   (mouse/pen, ≥768px; touch keeps scrolling), tidy-up, the lamp switch and
   the story booklet's page turner. Dragging is decorative: every object is
   fully usable by click, tap or keyboard without it. */
import { getState, setMinutes, subscribe } from "./time-state.js";
import { isNight } from "./sky-palette.js";
import { toast } from "./toast.js";

const DRAG_THRESHOLD = 6;
const NO_DRAG = "input, textarea, select, label, a, button:not(.booklet-cover):not(.cv-folder), [data-no-drag]";

export function initDesk(desk) {
  const objects = [...desk.querySelectorAll(".obj")];
  const wide = matchMedia("(min-width: 768px)");
  const tidy = desk.querySelector("[data-tidy]");
  let z = 10;

  /* slight random tilt each visit */
  for (const o of objects) {
    const base = parseFloat(o.style.getPropertyValue("--tilt")) || 0;
    const jitter = (Math.random() - 0.5) * 2.4;
    o.style.setProperty("--tilt", `${(base + jitter).toFixed(2)}deg`);
  }

  /* drag */
  for (const o of objects) {
    o.classList.add("can-drag");
    o.addEventListener("pointerdown", (e) => {
      if (!wide.matches || e.pointerType === "touch" || e.button !== 0) return;
      if (e.target.closest(NO_DRAG)) return;
      const trigger = o.querySelector(".booklet-cover, .cv-folder");
      const startX = e.clientX;
      const startY = e.clientY;
      const dx0 = parseFloat(o.style.getPropertyValue("--dx")) || 0;
      const dy0 = parseFloat(o.style.getPropertyValue("--dy")) || 0;
      const bounds = desk.getBoundingClientRect();
      const rect = o.getBoundingClientRect();
      let dragging = false;

      const move = (ev) => {
        let dx = ev.clientX - startX;
        let dy = ev.clientY - startY;
        if (!dragging) {
          if (Math.hypot(dx, dy) < DRAG_THRESHOLD) return;
          dragging = true;
          o.setPointerCapture(e.pointerId);
          o.classList.add("is-dragging");
          o.style.zIndex = String(++z);
        }
        // keep at least 60px of the object on the desk
        dx = Math.max(bounds.left - rect.right + 60, Math.min(bounds.right - rect.left - 60, dx));
        dy = Math.max(bounds.top - rect.bottom + 60, Math.min(bounds.bottom - rect.top - 60, dy));
        o.style.setProperty("--dx", `${dx0 + dx}px`);
        o.style.setProperty("--dy", `${dy0 + dy}px`);
        ev.preventDefault();
      };
      const up = () => {
        o.removeEventListener("pointermove", move);
        o.removeEventListener("pointerup", up);
        o.removeEventListener("pointercancel", up);
        if (!dragging) return;
        o.classList.remove("is-dragging");
        if (trigger) {
          trigger.dataset.dragged = "1"; // swallow the click that follows a drag
          setTimeout(() => delete trigger.dataset.dragged, 0);
        }
        if (tidy) tidy.hidden = false;
      };
      o.addEventListener("pointermove", move);
      o.addEventListener("pointerup", up);
      o.addEventListener("pointercancel", up);
    });
  }

  tidy?.addEventListener("click", () => {
    for (const o of objects) {
      o.style.setProperty("--dx", "0px");
      o.style.setProperty("--dy", "0px");
      o.style.zIndex = "";
    }
    tidy.hidden = true;
    toast("Desk tidied. Everything back in its place.", { emoji: "🧹" });
    desk.querySelector(".booklet-cover")?.focus();
  });

  /* lamp = night switch */
  const lamp = desk.querySelector("[data-lamp]");
  if (lamp) {
    let wasNight = null;
    subscribe(({ minutes }) => {
      const night = isNight(minutes);
      lamp.setAttribute("aria-pressed", String(night));
      // the lamp flickers on when night falls (not on first load)
      if (wasNight === false && night && !matchMedia("(prefers-reduced-motion: reduce)").matches) {
        desk.classList.remove("lamp-flicker");
        void desk.offsetWidth;
        desk.classList.add("lamp-flicker");
        setTimeout(() => desk.classList.remove("lamp-flicker"), 1000);
      }
      wasNight = night;
    });
    lamp.addEventListener("click", () => {
      const toNight = !isNight(getState().minutes);
      setMinutes(toNight ? 1320 : 720);
      toast(toNight ? "Lamp on. Working late, are we?" : "Lamp off. Daylight's back.", { emoji: toNight ? "💡" : "☀️" });
    });
  }

  initBooklet(document.querySelector("[data-booklet]"));
}

/* ---------- story booklet: a little book ----------
   3D page turns on the spine (css/booklet.css), drag/swipe a page to turn
   it, click the curled corner, jump with the index tabs or number keys,
   Home/End, and the arrow keys. The ribbon swings when a page turns, and
   each page's content arrives as it opens. Reduced motion: instant turns. */
function initBooklet(book) {
  if (!book) return;
  const reduce = matchMedia("(prefers-reduced-motion: reduce)");
  const dialog = book.closest("dialog");
  const pages = [...book.querySelectorAll(".page")];
  const prev = book.querySelector("[data-page-prev]");
  const next = book.querySelector("[data-page-next]");
  const label = book.querySelector("[data-page-label]");
  const tabs = [...book.querySelectorAll("[data-page-jump]")];
  const corner = book.querySelector("[data-page-corner]");
  const ribbon = book.querySelector(".booklet__ribbon");
  let i = 0;

  // decorate pages once: stacking order, running header, folio, stagger indices, skill chips
  pages.forEach((p, k) => {
    p.style.setProperty("--k", String(k));
    const run = document.createElement("p");
    run.className = "page__running";
    run.setAttribute("aria-hidden", "true");
    run.innerHTML = `<span>Jana · my story</span><span>${p.dataset.page.toLowerCase()}</span>`;
    p.prepend(run);
    if (k > 0) {
      const folio = document.createElement("p");
      folio.className = "page__folio";
      folio.setAttribute("aria-hidden", "true");
      folio.textContent = `— ${k} —`;
      p.append(folio);
    }
    p.querySelectorAll(".timeline__item, .pillars li, .skills > div, .page__block, .certs li").forEach((el, n) => el.style.setProperty("--n", String(n)));
    p.querySelectorAll(".skills dd").forEach((dd) => {
      const items = dd.textContent.split("·").map((t) => t.trim()).filter(Boolean);
      dd.innerHTML = `<span class="skill-chips">${items
        .map((t, c) => `<span class="skill-chip" style="--c:${c}">${t}</span>`)
        .join('<span class="visually-hidden">, </span>')}</span>`;
    });
  });

  const name = (n) => pages[n]?.dataset.page || "";
  function show(n, { announce = true } = {}) {
    const to = Math.max(0, Math.min(pages.length - 1, n));
    const moved = to !== i;
    const forward = to > i;
    i = to;
    pages.forEach((p, k) => {
      p.style.transform = "";
      p.classList.remove("is-dragging", "is-revealed");
      p.classList.toggle("is-current", k === i);
      p.classList.toggle("is-before", k < i);
      p.inert = k !== i;
      if (k === i) p.scrollTop = 0;
    });
    if (moved && forward && !reduce.matches) {
      void pages[i].offsetWidth;
      pages[i].classList.add("is-revealed");
    }
    if (moved && ribbon && !reduce.matches) {
      ribbon.classList.remove("is-swinging");
      void ribbon.offsetWidth;
      ribbon.classList.add("is-swinging");
    }
    prev.disabled = i === 0;
    next.disabled = i === pages.length - 1;
    if (corner) corner.hidden = i === pages.length - 1;
    tabs.forEach((t) => (Number(t.dataset.pageJump) === i ? t.setAttribute("aria-current", "page") : t.removeAttribute("aria-current")));
    prev.setAttribute("aria-label", i === 0 ? "Previous page" : `Previous page: ${name(i - 1)}`);
    next.setAttribute("aria-label", i === pages.length - 1 ? "Next page" : `Next page: ${name(i + 1)}`);
    label.textContent = name(i).toLowerCase();
    label.setAttribute("aria-label", `Page ${i + 1} of ${pages.length}: ${name(i)}`);
    label.setAttribute("aria-live", announce ? "polite" : "off");
    // keep focus on a usable control when an end is reached
    if (document.activeElement?.disabled) (i === 0 ? next : prev).focus();
  }
  prev.addEventListener("click", () => show(i - 1));
  next.addEventListener("click", () => show(i + 1));
  corner?.addEventListener("click", () => show(i + 1));
  tabs.forEach((t) => t.addEventListener("click", () => show(Number(t.dataset.pageJump))));
  ribbon?.addEventListener("animationend", () => ribbon.classList.remove("is-swinging"));

  // listen on the document: after a drag, focus may not be inside the book
  document.addEventListener("keydown", (e) => {
    if (!dialog?.open || e.defaultPrevented || e.target.closest?.("input, textarea")) return;
    const k = e.key;
    let to = null;
    if (k === "ArrowRight" || k === "PageDown") to = i + 1;
    else if (k === "ArrowLeft" || k === "PageUp") to = i - 1;
    else if (k === "Home") to = 0;
    else if (k === "End") to = pages.length - 1;
    else if (/^[1-9]$/.test(k) && Number(k) <= pages.length) to = Number(k) - 1;
    if (to === null) return;
    e.preventDefault();
    show(to);
  });

  // drag / swipe a page: left turns forward, right turns back
  const box = book.querySelector("[data-pages]");
  let drag = null;
  box?.addEventListener("pointerdown", (e) => {
    if (e.button !== 0 || e.target.closest("a, button, input, textarea, [data-page-corner]")) return;
    drag = { x: e.clientX, y: e.clientY, w: box.clientWidth, dir: 0, id: e.pointerId };
  });
  box?.addEventListener("pointermove", (e) => {
    if (!drag || e.pointerId !== drag.id) return;
    const dx = e.clientX - drag.x;
    if (!drag.dir) {
      if (Math.abs(dx) < 8 || Math.abs(dx) < Math.abs(e.clientY - drag.y)) return;
      drag.dir = dx < 0 ? 1 : -1; // 1 = forward
      if ((drag.dir === 1 && i === pages.length - 1) || (drag.dir === -1 && i === 0)) {
        drag = null;
        return;
      }
      box.setPointerCapture(e.pointerId);
      box.classList.add("is-dragging");
      getSelection()?.removeAllRanges();
    }
    if (reduce.matches) return;
    // reach 90° (the page edge-on) at about a third of the width
    const t = Math.max(0, Math.min(1, (Math.abs(dx) / drag.w) * 1.6));
    if (drag.dir === 1) {
      pages[i].classList.add("is-dragging");
      pages[i].style.transform = `rotateY(${-t * 179}deg)`;
    } else {
      const p = pages[i - 1];
      p.classList.add("is-dragging");
      p.style.visibility = "visible";
      p.style.transform = `rotateY(${-179 + t * 179}deg)`;
    }
  });
  const end = (e) => {
    if (!drag || e.pointerId !== drag.id) return;
    const dx = e.clientX - drag.x;
    const turned = drag.dir && Math.abs(dx) > drag.w * 0.22;
    const dir = drag.dir;
    drag = null;
    box.classList.remove("is-dragging");
    pages.forEach((p) => (p.style.visibility = ""));
    if (turned) show(i + dir);
    else show(i, { announce: false });
    pages[i].focus({ preventScroll: true });
  };
  box?.addEventListener("pointerup", end);
  box?.addEventListener("pointercancel", end);

  dialog?.addEventListener("dialog:open", () => {
    show(0, { announce: false });
    next.focus();
  });
  show(0, { announce: false });
}
