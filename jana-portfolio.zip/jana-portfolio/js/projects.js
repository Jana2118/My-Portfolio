/* projects.js — the All projects page.
   Filter chips (one at a time), free-text search, grid/list layout, all kept in
   the URL (?type=mobile&q=admin&view=list). Changes animate with a same-document
   View Transition where supported (cards glide to their new places), else the
   newly shown cards pop in. Cards rise in a stagger as they scroll into view.
   Quick look dialogs get a small carousel (arrows, dots, scroll-snap);
   #p-<slug> opens one directly (used by the home Work cards).
   Everything works without motion; nothing depends on JS to be visible. */
import { openDialog } from "./dialog.js";

const reduce = matchMedia("(prefers-reduced-motion: reduce)");

export function initProjects(root) {
  const grid = root.querySelector("[data-grid]");
  const cards = [...grid.querySelectorAll(".pj")];
  const filters = [...root.querySelectorAll("[data-filter]")];
  const views = [...root.querySelectorAll("[data-view]")];
  const search = root.querySelector("[data-search-input]");
  const count = root.querySelector("[data-count]");
  const empty = root.querySelector("[data-empty]");
  const total = cards.length;

  const params = new URLSearchParams(location.search);
  const state = {
    type: filters.some((b) => b.dataset.filter === params.get("type")) ? params.get("type") : "all",
    q: (params.get("q") || "").trim(),
    view: params.get("view") === "list" ? "list" : "grid",
  };
  if (search) search.value = state.q;

  const label = (k) => filters.find((b) => b.dataset.filter === k)?.firstChild.textContent.trim() || "";
  const matches = (card) => {
    const inType = state.type === "all" || card.dataset.cats.split(" ").includes(state.type);
    const words = state.q.toLowerCase().split(/\s+/).filter(Boolean);
    return inType && words.every((w) => card.dataset.search.includes(w));
  };

  function render({ animate = false } = {}) {
    const before = new Set(cards.filter((c) => !c.hidden));
    let shown = 0;
    for (const card of cards) {
      const on = matches(card);
      card.hidden = !on;
      if (on) shown++;
    }
    filters.forEach((b) => b.setAttribute("aria-pressed", String(b.dataset.filter === state.type)));
    views.forEach((b) => b.setAttribute("aria-pressed", String(b.dataset.view === state.view)));
    grid.dataset.layout = state.view;
    empty.hidden = shown > 0;

    const what = state.type === "all" ? "" : ` in ${label(state.type)}`;
    const q = state.q ? ` matching “${state.q}”` : "";
    count.textContent = shown === total && !q ? `Showing all ${total} projects` : `Showing ${shown} of ${total} projects${what}${q}`;

    if (animate && !reduce.matches && !document.startViewTransition) {
      // fallback animation: pop the cards that just appeared
      let k = 0;
      for (const card of cards) {
        if (card.hidden || before.has(card)) continue;
        card.classList.remove("is-pop");
        card.style.setProperty("--d", `${Math.min(k++, 8) * 45}ms`);
        void card.offsetWidth;
        card.classList.add("is-pop");
        card.classList.add("is-in");
      }
    }
    if (animate) {
      count.classList.remove("is-bump");
      void count.offsetWidth;
      count.classList.add("is-bump");
    }
  }

  function syncUrl() {
    const p = new URLSearchParams(location.search);
    state.type === "all" ? p.delete("type") : p.set("type", state.type);
    state.q ? p.set("q", state.q) : p.delete("q");
    state.view === "grid" ? p.delete("view") : p.set("view", state.view);
    const qs = p.toString();
    history.replaceState(null, "", `${location.pathname}${qs ? `?${qs}` : ""}${location.hash}`);
  }

  function update(change) {
    Object.assign(state, change);
    syncUrl();
    // reveal everything that is about to show, so a transition never lands on hidden cards
    cards.forEach((c) => c.classList.add("is-in"));
    if (document.startViewTransition && !reduce.matches) {
      document.startViewTransition(() => render({ animate: true }));
    } else {
      render({ animate: true });
    }
  }

  filters.forEach((b) => b.addEventListener("click", () => update({ type: b.dataset.filter })));
  views.forEach((b) => b.addEventListener("click", () => update({ view: b.dataset.view })));
  root.querySelector("[data-reset]")?.addEventListener("click", () => {
    if (search) search.value = "";
    update({ type: "all", q: "" });
    filters[0]?.focus();
  });
  let t = 0;
  search?.addEventListener("input", () => {
    clearTimeout(t);
    t = setTimeout(() => update({ q: search.value.trim() }), 160);
  });
  search?.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && search.value) {
      e.stopPropagation();
      search.value = "";
      update({ q: "" });
    }
  });

  render();

  // staggered entrance as cards scroll into view (each batch staggers from 0)
  if (!reduce.matches && "IntersectionObserver" in window) {
    grid.classList.add("pj-anim");
    let batch = [];
    let raf = 0;
    const io = new IntersectionObserver(
      (entries) => {
        for (const e of entries) {
          if (!e.isIntersecting) continue;
          io.unobserve(e.target);
          batch.push(e.target);
        }
        if (!raf && batch.length) {
          raf = requestAnimationFrame(() => {
            batch.forEach((card, k) => {
              card.style.setProperty("--d", `${Math.min(k, 7) * 80}ms`);
              card.classList.add("is-in");
            });
            batch = [];
            raf = 0;
          });
        }
      },
      { rootMargin: "0px 0px -6% 0px", threshold: 0.08 }
    );
    cards.forEach((c) => (c.hidden ? c.classList.add("is-in") : io.observe(c)));
    // after the entrance, drop the delay so hover/tilt stay instant
    grid.addEventListener("transitionend", (e) => {
      if (e.propertyName === "opacity" && e.target.classList?.contains("pj")) e.target.style.setProperty("--d", "0ms");
    });
  }

  initQuickLooks(document);

  // #p-<slug> (from a home card): scroll to the card and open its Quick look.
  // Waits for the incoming cross-page View Transition so it isn't aborted.
  const slug = location.hash.startsWith("#p-") ? location.hash.slice(3) : "";
  const dlg = slug && document.getElementById(`ql-${slug}`);
  const trigger = dlg && document.querySelector(`#p-${CSS.escape(slug)} .pj__link`);
  if (dlg && trigger) {
    trigger.closest(".pj")?.classList.add("is-in");
    const go = () => {
      history.replaceState(null, "", location.pathname + location.search);
      trigger.scrollIntoView({ block: "center", behavior: "auto" });
      openDialog(dlg, trigger);
    };
    const vt = document.activeViewTransition;
    if (vt) vt.finished.then(go, go);
    else setTimeout(go, reduce.matches ? 0 : 560); // older engines: let the page transition (520 ms) land first
  }
}

/* ---------- Quick look carousels ---------- */
function initQuickLooks(scope) {
  for (const dlg of scope.querySelectorAll("[data-ql]")) {
    const track = dlg.querySelector("[data-ql-track]");
    if (!track) continue; // e.g. the live design-system sheet
    const figs = [...track.children];
    const dots = [...dlg.querySelectorAll("[data-ql-go]")];
    if (figs.length < 2) continue;
    const current = () => Math.round(track.scrollLeft / Math.max(1, track.clientWidth));
    const go = (i) => {
      const n = (i + figs.length) % figs.length;
      track.scrollTo({ left: n * track.clientWidth, behavior: reduce.matches ? "auto" : "smooth" });
    };
    dlg.querySelectorAll("[data-ql-step]").forEach((b) =>
      b.addEventListener("click", () => go(current() + Number(b.dataset.qlStep)))
    );
    dots.forEach((d) => d.addEventListener("click", () => go(Number(d.dataset.qlGo))));
    let raf = 0;
    track.addEventListener("scroll", () => {
      if (raf) return;
      raf = requestAnimationFrame(() => {
        raf = 0;
        const i = current();
        dots.forEach((d, k) => (k === i ? d.setAttribute("aria-current", "true") : d.removeAttribute("aria-current")));
      });
    });
    track.addEventListener("keydown", (e) => {
      if (e.key === "ArrowRight" || e.key === "ArrowLeft") {
        e.preventDefault();
        go(current() + (e.key === "ArrowRight" ? 1 : -1));
      }
    });
    dlg.addEventListener("dialog:open", () => {
      track.scrollLeft = 0;
    });
  }
}
