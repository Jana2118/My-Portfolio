/* nav.js — sticky nav state, active section, theme quick-toggle, and résumé
   links that never 404 (they check the PDF first and explain if it's missing). */
import { getState, setMinutes, subscribe } from "./time-state.js";
import { isNight } from "./sky-palette.js";
import { LINKS } from "./config.js";
import { toast } from "./toast.js";

export function initNav(nav) {
  /* scrolled state */
  const onScroll = () => nav.classList.toggle("is-scrolled", window.scrollY > 24);
  onScroll();
  addEventListener("scroll", onScroll, { passive: true });

  /* active section (aria-current) */
  const links = [...nav.querySelectorAll('a[href*="#"]')].filter((a) => {
    const id = a.hash.slice(1);
    return id && a.pathname === location.pathname && document.getElementById(id);
  });
  if (links.length && "IntersectionObserver" in window) {
    const byId = new Map(links.map((a) => [a.hash.slice(1), a]));
    const io = new IntersectionObserver(
      (entries) => {
        for (const e of entries) {
          const a = byId.get(e.target.id);
          if (!a) continue;
          if (e.isIntersecting) {
            links.forEach((l) => l.removeAttribute("aria-current"));
            a.setAttribute("aria-current", "true");
          } else if (a.getAttribute("aria-current")) {
            a.removeAttribute("aria-current");
          }
        }
      },
      { rootMargin: "-45% 0px -50% 0px" }
    );
    byId.forEach((_, id) => io.observe(document.getElementById(id)));
  }

  /* theme quick toggle: jumps the sky to noon or 22:00 */
  const toggle = nav.querySelector("[data-theme-toggle]");
  const icon = nav.querySelector("[data-theme-icon]");
  const brandIcon = nav.querySelector("[data-brand-icon]");
  subscribe(({ minutes }) => {
    const night = isNight(minutes);
    toggle?.setAttribute("aria-pressed", String(night));
    if (icon) icon.textContent = night ? "🌙" : "☀️";
    if (toggle) toggle.title = night ? "Night sky is on. Press for day (12:00)" : "Press for night sky (22:00)";
    if (brandIcon) brandIcon.textContent = night ? "🌙" : "☀️";
  });
  toggle?.addEventListener("click", () => {
    const toNight = !isNight(getState().minutes);
    setMinutes(toNight ? 1320 : 720);
    toast(toNight ? "Goodnight mode. The moon's out." : "Good morning! The sun's up.", { emoji: toNight ? "🌙" : "☀️" });
  });
}

/* Résumé links: [data-resume]. If the PDF isn't uploaded yet, show a toast. */
let resumeOk = null;
async function resumeAvailable() {
  if (resumeOk !== null) return resumeOk;
  try {
    const r = await fetch(LINKS.resume, { method: "HEAD", cache: "no-store" });
    const type = r.headers.get("content-type") || "";
    resumeOk = r.ok && !type.includes("text/html");
  } catch {
    resumeOk = false;
  }
  return resumeOk;
}

export function initResumeLinks(scope = document) {
  for (const a of scope.querySelectorAll("[data-resume]")) {
    if (a.dataset.resumeWired) continue;
    a.dataset.resumeWired = "1";
    a.href = LINKS.resume;
    a.addEventListener("click", async (e) => {
      if (resumeOk === true) return; // known good: let the browser handle it
      e.preventDefault();
      if (await resumeAvailable()) {
        if (a.hasAttribute("download")) {
          const tmp = document.createElement("a");
          tmp.href = LINKS.resume;
          tmp.download = "";
          tmp.click();
        } else {
          window.open(LINKS.resume, "_blank", "noopener");
        }
      } else {
        toast("My résumé PDF is on its way. Say hello and I'll send it over.", { emoji: "📄" });
      }
    });
  }
}
