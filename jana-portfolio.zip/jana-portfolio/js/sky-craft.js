/* sky-craft.js — a little life in the hero sky (styles: end of css/sky.css).
   · By day a fighter jet crosses slowly, leaving a contrail; at sunrise and
     sunset a hot-air balloon usually drifts by instead. By night an alien
     saucer drifts over, hovers and shines a light ray below it.
   · Click (or tap) one: the jet fires two missiles, the saucer zaps a laser
     down to the sea, the balloon fires its burner and rises.
   · At night the lighthouse goes looking: its beam leaves the sea and sweeps
     the sky as a searchlight (on its own while a saucer is out, or when the
     lighthouse is clicked). If it catches the saucer, the saucer lights up,
     flashes back, switches its ray off and darts away.
   · Shooting stars streak across the night sky; click one to make a wish.
   Craft follow the sky's time, so dragging the sun swaps them. Clicks on
   plain hero text that sits over a craft or a shooting star still count.
   Purely decorative (aria-hidden, pointer only); nothing runs under
   prefers-reduced-motion, when the hero is off screen, or when the tab is
   hidden. */
import { getState, subscribe } from "./time-state.js";
import { isNight } from "./sky-palette.js";
import { toast } from "./toast.js";

const reduce = matchMedia("(prefers-reduced-motion: reduce)");
const rand = (a, b) => a + Math.random() * (b - a);
const pick = (list) => list[Math.floor(Math.random() * list.length)];
const golden = (m) => (m >= 360 && m < 450) || (m >= 1020 && m < 1110);
const DEG = Math.PI / 180;

const WISHES = [
  "Wish made: may every handoff be pixel-perfect.",
  "Wish made: may your users always find the button.",
  "Wish made: may every design review be a short one.",
  "Wish made: may all your layers be named.",
  "Wish made: may the next sprint hold no surprises.",
];

/* Realistic-looking craft, drawn as shaded SVG (gradients, highlights, panel
   lines). "{S}" is replaced with a unique suffix so gradient ids never clash. */
const JET = `<svg viewBox="0 0 200 64" focusable="false">
  <defs>
    <linearGradient id="jb{S}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#eef1f5"/><stop offset=".45" stop-color="#a9b2bd"/><stop offset="1" stop-color="#59616d"/></linearGradient>
    <linearGradient id="jw{S}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#8a94a0"/><stop offset="1" stop-color="#454c57"/></linearGradient>
    <linearGradient id="jc{S}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#9fc3ee"/><stop offset=".45" stop-color="#3f5f8f"/><stop offset="1" stop-color="#16223a"/></linearGradient>
    <linearGradient id="jn{S}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#5a616b"/><stop offset="1" stop-color="#15181c"/></linearGradient>
    <radialGradient id="jf{S}" cx="1" cy=".5" r="1"><stop offset="0" stop-color="#fff"/><stop offset=".25" stop-color="#ffe2a0"/><stop offset=".55" stop-color="#ff7a2f" stop-opacity=".85"/><stop offset="1" stop-color="#ff3d00" stop-opacity="0"/></radialGradient>
  </defs>
  <ellipse class="jet__flame" cx="4" cy="33.5" rx="14" ry="3.8" fill="url(#jf{S})"/>
  <path d="M30 33 L13 41 L26 42 L52 35 Z" fill="url(#jw{S})"/>
  <path d="M30 30 L19 5 L35 5 L54 28 Z" fill="url(#jb{S})"/>
  <path d="M24.5 12 L34 12 L41 21 L29 21 Z" fill="#b5361f" opacity=".85"/>
  <path d="M14 30 L22 29.4 L22 37.6 L14 37 Z" fill="url(#jn{S})"/>
  <path d="M21 30 C40 26 70 25 110 25 C140 25 165 27 182 31 C190 32.5 196 33.5 199 34 C196 34.5 190 35.5 182 37 C165 40 140 41 110 41 C70 41 40 40 21 37.6 Z" fill="url(#jb{S})"/>
  <path d="M24 37.2 C60 39.6 120 40.6 182 37" fill="none" stroke="#000" stroke-opacity=".22" stroke-width="1.6"/>
  <path d="M40 27.6 C80 25.6 140 25.6 178 29.8" fill="none" stroke="#fff" stroke-opacity=".55" stroke-width=".9"/>
  <path d="M60 26 V40 M95 25.5 V41 M128 25.5 V41 M166 28 V39" stroke="#000" stroke-opacity=".16" stroke-width=".6"/>
  <path d="M120 38 L150 37 L146 43 L124 43 Z" fill="#2b3038"/>
  <path d="M84 44.6 h26 l4 1.6 -4 1.6 h-26 z M84 44.6 l-4 -2 v7.2 l4 -2" fill="#d9dde3"/>
  <path d="M80 36 L57 57 L76 58 L120 38 Z" fill="url(#jw{S})"/>
  <path d="M81 36.4 L60 55.6" stroke="#fff" stroke-opacity=".35" stroke-width=".8"/>
  <path d="M138 26.2 C146 17.5 162 17.5 172.5 26.4 C164 27.8 150 28.2 138 27.2 Z" fill="url(#jc{S})"/>
  <path d="M146 22 C152 19.4 160 19.4 166 22" fill="none" stroke="#fff" stroke-opacity=".7" stroke-width="1.1"/>
  <circle class="jet__nav" cx="66" cy="55" r="1.5" fill="#ff3b30"/>
  <circle class="jet__strobe" cx="21" cy="6" r="1.3" fill="#fff"/>
</svg>`;

const UFO = `<svg viewBox="0 0 160 80" focusable="false">
  <defs>
    <radialGradient id="ud{S}" cx=".38" cy=".3" r=".9"><stop offset="0" stop-color="#fff" stop-opacity=".95"/><stop offset=".35" stop-color="#cdeeff" stop-opacity=".6"/><stop offset="1" stop-color="#2f5c99" stop-opacity=".55"/></radialGradient>
    <linearGradient id="uh{S}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#f5f7fb"/><stop offset=".38" stop-color="#b8c0ce"/><stop offset=".62" stop-color="#7a8395"/><stop offset="1" stop-color="#363d4c"/></linearGradient>
    <linearGradient id="ur{S}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#596276"/><stop offset="1" stop-color="#1f2431"/></linearGradient>
    <radialGradient id="uc{S}" cx=".5" cy=".5" r=".5"><stop offset="0" stop-color="#f0fff8"/><stop offset=".35" stop-color="#7dffc8"/><stop offset=".75" stop-color="#1fae7c" stop-opacity=".6"/><stop offset="1" stop-color="#1fae7c" stop-opacity="0"/></radialGradient>
  </defs>
  <ellipse class="ufo__core" cx="80" cy="54" rx="36" ry="8" fill="url(#uc{S})"/>
  <path d="M9 42 C30 57 130 57 151 42 Z" fill="url(#ur{S})"/>
  <ellipse cx="80" cy="40" rx="72" ry="14" fill="url(#uh{S})"/>
  <path d="M22 36.5 C50 29.5 110 29.5 138 36.5" fill="none" stroke="#fff" stroke-opacity=".75" stroke-width="1.4"/>
  <path d="M12 43 C40 50 120 50 148 43" fill="none" stroke="#1f2431" stroke-opacity=".55" stroke-width="1.6"/>
  <circle class="ufo__light" style="--l:0" cx="20" cy="45" r="2.3"/><circle class="ufo__light" style="--l:1" cx="38" cy="48" r="2.3"/>
  <circle class="ufo__light" style="--l:2" cx="58" cy="49.6" r="2.3"/><circle class="ufo__light" style="--l:3" cx="80" cy="50.2" r="2.3"/>
  <circle class="ufo__light" style="--l:4" cx="102" cy="49.6" r="2.3"/><circle class="ufo__light" style="--l:5" cx="122" cy="48" r="2.3"/>
  <circle class="ufo__light" style="--l:6" cx="140" cy="45" r="2.3"/>
  <ellipse cx="80" cy="30.5" rx="29" ry="5.2" fill="#8a93a6"/>
  <path d="M51 30.5 C51 8 109 8 109 30.5 Z" fill="url(#ud{S})"/>
  <path d="M60 22 C64 14.5 74 12.2 83 13.2" fill="none" stroke="#fff" stroke-opacity=".8" stroke-width="1.6" stroke-linecap="round"/>
</svg>`;

const BALLOON = `<svg viewBox="0 0 100 140" focusable="false">
  <defs>
    <clipPath id="bc{S}"><path d="M50 3 C79 3 97 24 96 48 C95 68 78 84 64 97 L36 97 C22 84 5 68 4 48 C3 24 21 3 50 3 Z"/></clipPath>
    <radialGradient id="bs{S}" cx=".34" cy=".28" r=".85"><stop offset="0" stop-color="#fff" stop-opacity=".4"/><stop offset=".45" stop-color="#fff" stop-opacity="0"/><stop offset="1" stop-color="#1a0f0a" stop-opacity=".5"/></radialGradient>
    <linearGradient id="bk{S}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#a47148"/><stop offset="1" stop-color="#5e3b22"/></linearGradient>
    <radialGradient id="bf{S}" cx=".5" cy=".75" r=".65"><stop offset="0" stop-color="#fff"/><stop offset=".35" stop-color="#ffd37a"/><stop offset=".7" stop-color="#ff7a2f" stop-opacity=".85"/><stop offset="1" stop-color="#ff4b1f" stop-opacity="0"/></radialGradient>
    <radialGradient id="bg{S}" cx=".5" cy="1" r=".75"><stop offset="0" stop-color="#ffd37a" stop-opacity=".95"/><stop offset="1" stop-color="#ff7a2f" stop-opacity="0"/></radialGradient>
  </defs>
  <g clip-path="url(#bc{S})">
    <rect width="100" height="100" fill="#efe2c6"/>
    <path d="M50 3 C18.0 6 0.8 26 4.0 48 C5.2 68 26.0 86 36.0 97 L39.5 97 C32.0 86 16.4 68 15.5 48 C13.1 26 26.0 6 50 3 Z M50 3 C34.0 6 25.4 26 27.0 48 C27.6 68 38.0 86 43.0 97 L46.5 97 C44.0 86 38.8 68 38.5 48 C37.7 26 42.0 6 50 3 Z M50 3 C50.0 6 50.0 26 50.0 48 C50.0 68 50.0 86 50.0 97 L53.5 97 C56.0 86 61.2 68 61.5 48 C62.3 26 58.0 6 50 3 Z M50 3 C66.0 6 74.6 26 73.0 48 C72.4 68 62.0 86 57.0 97 L60.5 97 C68.0 86 83.6 68 84.5 48 C86.9 26 74.0 6 50 3 Z" fill="#c8452c"/>
    <path d="M0 43 Q50 55 100 43 V51 Q50 63 0 51 Z" fill="#e8a33a"/>
    <rect width="100" height="100" fill="url(#bs{S})"/>
    <ellipse class="balloon__glow" cx="50" cy="98" rx="24" ry="20" fill="url(#bg{S})"/>
  </g>
  <path d="M36 97 H64 L60 104 H40 Z" fill="#7a2a1a"/>
  <path d="M40 104 L42.6 118 M60 104 L57.4 118 M46 104 L47 118 M54 104 L53 118" stroke="#3a2a1e" stroke-width=".6"/>
  <path class="balloon__flame" d="M50 116 C45.5 112 47 107.5 50 103 C53 107.5 54.5 112 50 116 Z" fill="url(#bf{S})"/>
  <rect x="46.5" y="115.4" width="7" height="2.6" rx=".6" fill="#585d66"/>
  <path d="M42 118 H58 L56.5 130 H43.5 Z" fill="url(#bk{S})"/>
  <path d="M42.6 122 H57.4 M43.1 126 H56.9 M47 118 V130 M50 118 V130 M53 118 V130" stroke="#3d2614" stroke-opacity=".45" stroke-width=".5"/>
</svg>`;

export function initSkyCraft(hero) {
  if (!hero || reduce.matches || !Element.prototype.animate) return;

  const layer = document.createElement("div");
  layer.className = "sky__craft";
  layer.setAttribute("aria-hidden", "true");
  hero.insertBefore(layer, hero.querySelector(".hero__inner"));

  let visible = true;
  let current = null; // { el, anim, kind, ltr }
  let timer = 0;
  const toasted = new Set();
  const meteors = new Set(); // { el, hit, anim }

  const night = () => isNight(getState().minutes);
  const live = () => visible && document.visibilityState === "visible";
  const once = (key, msg, emoji) => {
    if (toasted.has(key)) return;
    toasted.add(key);
    toast(msg, { emoji });
  };
  const local = (r) => {
    const lr = layer.getBoundingClientRect();
    return { x: r.left - lr.left, y: r.top - lr.top, w: r.width, h: r.height, W: lr.width, H: lr.height };
  };

  const io = new IntersectionObserver(([e]) => {
    visible = e.isIntersecting;
    if (visible && !current) schedule(1500);
  });
  io.observe(hero);
  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "visible" && !current) schedule(1500);
  });

  // ---- hits on plain hero text that sits over a craft or a shooting star ----
  const SKIP = 'a, button, input, select, textarea, label, [tabindex]:not([tabindex="-1"]), .sky__body, .sky__panel, .craft, .meteor, .lighthouse-hit';
  const targetAt = (e) => {
    const hit = e.target.closest(SKIP);
    if (hit && hero.contains(hit)) return null;
    const list = [];
    if (current) list.push([current.el.querySelector(".craft__ship"), () => fire(current)]);
    for (const m of meteors) list.push([m.hit, () => wish(m)]);
    for (const [el, act] of list) {
      const r = el.getBoundingClientRect();
      if (e.clientX >= r.left && e.clientX <= r.right && e.clientY >= r.top && e.clientY <= r.bottom) return act;
    }
    return null;
  };
  hero.addEventListener("click", (e) => {
    const act = targetAt(e);
    if (act && !String(getSelection?.() || "")) act();
  });
  let aimRaf = 0;
  hero.addEventListener("pointermove", (e) => {
    if (aimRaf || e.pointerType !== "mouse") return;
    aimRaf = requestAnimationFrame(() => {
      aimRaf = 0;
      hero.classList.toggle("is-aiming", !!targetAt(e));
    });
  });

  function schedule(ms) {
    clearTimeout(timer);
    timer = setTimeout(spawn, ms);
  }

  function spawn() {
    if (current || !live()) return;
    const m = getState().minutes;
    const kind = isNight(m) ? "ufo" : golden(m) && Math.random() < 0.7 ? "balloon" : "jet";
    const W = hero.clientWidth;
    const H = hero.clientHeight;
    const el = document.createElement("div");
    el.className = `craft craft--${kind}`;
    const ltr = Math.random() < 0.5;
    el.dataset.dir = ltr ? "ltr" : "rtl";
    const uid = Math.random().toString(36).slice(2, 8);
    const ship = (svg) => `<span class="craft__ship">${svg.replaceAll("{S}", uid)}</span>`;
    el.innerHTML =
      kind === "jet" ? `<span class="craft__trail"></span>${ship(JET)}`
      : kind === "ufo" ? `<span class="ufo-ray">${'<i class="mote"></i>'.repeat(7)}</span>${ship(UFO)}`
      : ship(BALLOON);
    el.querySelectorAll(".mote").forEach((mo) => {
      mo.style.setProperty("--mx", `${rand(15, 85).toFixed(0)}%`);
      mo.style.setProperty("--md", `${rand(0, 2.6).toFixed(2)}s`);
    });
    layer.append(el);

    const size =
      kind === "jet" ? Math.max(130, Math.min(200, W * 0.13))
      : kind === "ufo" ? Math.max(120, Math.min(180, W * 0.12))
      : Math.max(64, Math.min(100, W * 0.065));
    el.style.setProperty("--size", `${size}px`);
    const y0 = (kind === "jet" ? rand(0.08, 0.3) : kind === "ufo" ? rand(0.06, 0.2) : rand(0.1, 0.3)) * H;
    const from = ltr ? -size - 40 : W + 40;
    const to = ltr ? W + 40 : -size - 40;
    const x = (p) => from + (to - from) * p;
    let frames;
    let duration;
    if (kind === "jet") {
      frames = [
        { transform: `translate(${from}px, ${y0 + 14}px)` },
        { transform: `translate(${to}px, ${y0 - 14}px)` },
      ];
      duration = rand(25000, 32000); // slow, like a real jet at altitude
    } else if (kind === "ufo") {
      frames = [
        { transform: `translate(${x(0)}px, ${y0}px)`, offset: 0 },
        { transform: `translate(${x(0.3)}px, ${y0 + 24}px)`, offset: 0.28 },
        { transform: `translate(${x(0.44)}px, ${y0 + 8}px)`, offset: 0.42 },
        { transform: `translate(${x(0.46)}px, ${y0 + 4}px)`, offset: 0.6 },
        { transform: `translate(${x(0.72)}px, ${y0 + 20}px)`, offset: 0.8 },
        { transform: `translate(${x(1)}px, ${y0}px)`, offset: 1 },
      ];
      duration = rand(35000, 45000); // drifts, then hovers mid-sky
    } else {
      frames = [
        { transform: `translate(${x(0)}px, ${y0 + 12}px)`, easing: "ease-in-out" },
        { transform: `translate(${x(0.5)}px, ${y0 - 18}px)`, easing: "ease-in-out" },
        { transform: `translate(${x(1)}px, ${y0 + 6}px)` },
      ];
      duration = rand(55000, 70000); // drifting with the wind
    }
    const anim = el.animate(frames, { duration, easing: kind === "ufo" ? "ease-in-out" : "linear", fill: "forwards" });
    const c = { el, anim, kind, ltr };
    current = c;
    el.addEventListener("pointerdown", (e) => {
      if (e.button !== 0) return;
      e.preventDefault();
      e.stopPropagation();
      fire(c);
    });
    if (kind === "ufo") scheduleSearch(rand(6000, 10000));
    anim.finished.then(() => {
      el.remove();
      if (current === c) current = null;
      hero.classList.remove("is-aiming");
      clearTimeout(searchTimer);
      schedule(rand(2000, 5000));
    }, () => {});
  }

  function fire(c) {
    if (!c || !c.el.isConnected) return;
    const lr = layer.getBoundingClientRect();
    const r = c.el.querySelector(".craft__ship").getBoundingClientRect();
    const cx = r.left - lr.left + r.width / 2;
    const cy = r.top - lr.top + r.height / 2;
    c.el.classList.remove("is-firing");
    void c.el.offsetWidth;
    c.el.classList.add("is-firing");
    if (c.kind === "jet") {
      const dir = c.ltr ? 1 : -1;
      const nose = cx + dir * r.width * 0.12; // released from under the wings
      [-7, 7].forEach((dy, k) => {
        const m = document.createElement("span");
        m.className = "missile";
        m.dataset.dir = c.ltr ? "ltr" : "rtl";
        layer.append(m);
        const dist = rand(220, 320);
        const a = m.animate(
          [
            // the mirror (dir) goes after the translate, so it only flips the missile itself
            { transform: `translate(${nose}px, ${cy + r.height * 0.14}px) scaleX(${dir * 0.5})`, opacity: 1 },
            { transform: `translate(${nose + dir * dist * 0.25}px, ${cy + dy}px) scaleX(${dir})`, opacity: 1, offset: 0.3 },
            { transform: `translate(${nose + dir * dist}px, ${cy + dy * 2.2}px) scaleX(${dir * 1.15})`, opacity: 1 },
          ],
          { duration: 720 + k * 90, easing: "cubic-bezier(.5,0,.9,.6)", fill: "forwards" }
        );
        a.finished.then(() => {
          m.remove();
          burst(nose + dir * dist, cy + dy * 2.2, ["var(--c-craft-fire-2)", "var(--c-craft-fire)", "var(--c-craft-ray-3)", "var(--c-craft-fire-3)"], "fire");
        });
      });
      once("jet", "Pew pew! Contrails for days.", "✈️");
    } else if (c.kind === "ufo") {
      const ground = hero.querySelector(".sky__ground")?.getBoundingClientRect();
      const bottom = ground ? ground.top - lr.top + 26 : lr.height * 0.8;
      const top = r.bottom - lr.top - r.height * 0.15;
      const beam = document.createElement("span");
      beam.className = "beam";
      beam.style.left = `${cx}px`;
      beam.style.top = `${top}px`;
      beam.style.height = `${Math.max(40, bottom - top)}px`;
      layer.append(beam);
      beam.animate(
        [
          { transform: "translateX(-50%) scaleY(0)", opacity: 1 },
          { transform: "translateX(-50%) scaleY(1)", opacity: 1, offset: 0.12 },
          { opacity: 0.35, offset: 0.3 },
          { opacity: 1, offset: 0.42 },
          { opacity: 0.4, offset: 0.55 },
          { opacity: 1, offset: 0.66 },
          { transform: "translateX(-50%) scaleY(1)", opacity: 0 },
        ],
        { duration: 900, easing: "ease-out", fill: "forwards" }
      ).finished.then(() => beam.remove());
      setTimeout(() => {
        const ring = document.createElement("span");
        ring.className = "ripple";
        ring.style.left = `${cx}px`;
        ring.style.top = `${bottom}px`;
        layer.append(ring);
        ring.animate(
          [{ transform: "translate(-50%, -50%) scale(0.2)", opacity: 1 }, { transform: "translate(-50%, -50%) scale(2.6)", opacity: 0 }],
          { duration: 800, easing: "ease-out", fill: "forwards" }
        ).finished.then(() => ring.remove());
        burst(cx, bottom, ["var(--c-leaf)", "var(--c-craft-laser)", "var(--c-sky)", "var(--c-craft-ray-3)"], "zap");
      }, 140);
      once("ufo", "Zap! Don’t worry, they come in peace.", "👽");
    } else {
      // balloon: the pilot fires the burner and it climbs
      const prev = c.lift || 0;
      c.lift = Math.max(-160, prev - rand(28, 42));
      c.liftAnim?.cancel();
      c.liftAnim = c.el.animate([{ translate: `0px ${prev}px` }, { translate: `0px ${c.lift}px` }], {
        duration: 1800,
        easing: "cubic-bezier(.3,.6,.3,1)",
        fill: "forwards",
      });
      once("balloon", "Fwoosh! Just hot air on this one.", "🎈");
    }
  }

  function burst(x, y, colors, type) {
    if (type === "fire") {
      for (let k = 0; k < 6; k++) {
        const pf = document.createElement("span");
        pf.className = "puff";
        layer.append(pf);
        const ang = rand(0, Math.PI * 2);
        const d = rand(8, 26);
        pf.animate(
          [
            { transform: `translate(${x}px, ${y}px) scale(0.3)`, opacity: 0.85 },
            { transform: `translate(${x + Math.cos(ang) * d}px, ${y + Math.sin(ang) * d - 14}px) scale(${rand(1.4, 2.2)})`, opacity: 0 },
          ],
          { duration: rand(1300, 1900), easing: "cubic-bezier(.2,.7,.3,1)", fill: "forwards" }
        ).finished.then(() => pf.remove());
      }
    }
    const f = document.createElement("span");
    f.className = type === "fire" ? "flash" : `flash flash--${type}`;
    layer.append(f);
    f.animate(
      [{ transform: `translate(${x}px, ${y}px) scale(0.2)`, opacity: 1 }, { transform: `translate(${x}px, ${y}px) scale(1.6)`, opacity: 0 }],
      { duration: 480, easing: "ease-out", fill: "forwards" }
    ).finished.then(() => f.remove());
    const n = type === "star" ? 14 : 18;
    for (let k = 0; k < n; k++) {
      const s = document.createElement("span");
      s.className = type === "star" ? "spark spark--star" : "spark";
      s.style.background = colors[k % colors.length];
      layer.append(s);
      const ang = (k / n) * Math.PI * 2 + rand(-0.2, 0.2);
      const d = rand(30, type === "star" ? 70 : 90);
      s.animate(
        [
          { transform: `translate(${x}px, ${y}px) scale(1)`, opacity: 1 },
          { transform: `translate(${x + Math.cos(ang) * d}px, ${y + Math.sin(ang) * d + 10}px) scale(0.2)`, opacity: 0 },
        ],
        { duration: rand(520, 900), easing: "cubic-bezier(.2,.8,.2,1)", fill: "forwards" }
      ).finished.then(() => s.remove());
    }
  }

  // ---------------------------------------------------------------------
  // The lighthouse searchlight
  // ---------------------------------------------------------------------
  const tower = hero.querySelector(".g-lighthouse");
  const lamp = hero.querySelector(".g-lamp");
  const beam = document.createElement("span");
  beam.className = "searchlight";
  const towerHit = document.createElement("span");
  towerHit.className = "lighthouse-hit";
  towerHit.hidden = true;
  layer.append(beam, towerHit);
  let searchTimer = 0;
  let search = null; // running search state

  function lampPoint() {
    if (!lamp) return null;
    const p = local(lamp.getBoundingClientRect());
    const lx = p.x + p.w / 2;
    const ly = p.y + p.h / 2;
    return lx > 8 && lx < p.W - 8 && ly > 0 && ly < p.H ? { lx, ly, W: p.W, H: p.H } : null;
  }
  function placeLighthouse() {
    const ok = tower && night() && lampPoint();
    towerHit.hidden = !ok;
    if (!ok) return;
    const t = local(tower.getBoundingClientRect());
    Object.assign(towerHit.style, {
      left: `${t.x - 8}px`,
      top: `${t.y - 12}px`,
      width: `${t.w + 16}px`,
      height: `${Math.min(t.h + 12, t.H - t.y + 12)}px`,
    });
  }
  new ResizeObserver(placeLighthouse).observe(hero);
  placeLighthouse();
  towerHit.addEventListener("pointerdown", (e) => {
    if (e.button !== 0) return;
    e.preventDefault();
    startSearch();
    once("lighthouse", "The lighthouse keeper is on the lookout.", "🔦");
  });

  function scheduleSearch(ms) {
    clearTimeout(searchTimer);
    searchTimer = setTimeout(() => {
      if (current?.kind === "ufo") startSearch();
    }, ms);
  }

  function startSearch() {
    if (search || !night() || !live()) return;
    const at = lampPoint();
    if (!at) return;
    const len = Math.hypot(Math.max(at.lx, at.W - at.lx), at.ly) * 1.08;
    beam.style.setProperty("--len", `${len.toFixed(0)}px`);
    search = { ...at, a: -6, phase: "out", t: 0, caught: false, last: performance.now() };
    draw();
    hero.classList.add("is-searching");
    beam.classList.add("is-on");
    requestAnimationFrame(step);
  }
  function endSearch() {
    if (!search) return;
    search = null;
    beam.classList.remove("is-on");
    hero.classList.remove("is-searching");
    if (current?.kind === "ufo") scheduleSearch(rand(12000, 18000));
  }
  const draw = () => {
    beam.style.transform = `translate(${search.lx.toFixed(1)}px, ${search.ly.toFixed(1)}px) rotate(${search.a.toFixed(2)}deg)`;
  };
  const shipAngle = () => {
    if (current?.kind !== "ufo" || !search) return null;
    const r = local(current.el.querySelector(".craft__ship").getBoundingClientRect());
    return { a: Math.atan2(r.y + r.h / 2 - search.ly, r.x + r.w / 2 - search.lx) / DEG, x: r.x + r.w / 2, W: r.W };
  };
  function step(now) {
    const s = search;
    if (!s) return;
    if (!night()) return endSearch();
    const dt = Math.min(0.05, (now - s.last) / 1000);
    s.last = now;
    s.t += dt;
    const ship = shipAngle();
    if (s.phase === "out" || s.phase === "back") {
      // sweep across the sky (right → up → left) and back down again
      const goal = s.phase === "out" ? -174 : -6;
      const dir = Math.sign(goal - s.a);
      s.a += dir * 36 * dt;
      if (!s.caught && ship && Math.abs(ship.a - s.a) < 2.5) {
        s.resume = s.phase;
        s.phase = "lock";
        s.t = 0;
      } else if (Math.sign(goal - s.a) !== dir) {
        s.a = goal;
        if (s.phase === "out") s.phase = "back";
        else return endSearch();
      }
    } else if (s.phase === "lock") {
      // caught it: follow the saucer for a moment
      if (ship) s.a += (ship.a - s.a) * Math.min(1, dt * 10);
      if (s.t > 0.55 && !s.caught) {
        s.caught = true;
        spotted(ship, s.lx);
      }
      if (s.t > 1.3) {
        s.phase = "lost";
        s.t = 0;
      }
    } else if (s.phase === "lost") {
      // it got away: hold, then keep sweeping
      if (s.t > 0.8) s.phase = s.resume || "back";
    }
    draw();
    requestAnimationFrame(step);
  }
  function spotted(ship, lx) {
    const c = current;
    if (!c || c.kind !== "ufo") return;
    c.el.classList.add("is-spotted");
    // the saucer darts out of the beam, away from the lighthouse, then settles
    setTimeout(() => {
      if (!c.el.isConnected) return;
      let dx = (ship && ship.x < lx ? -1 : 1) * rand(90, 140);
      if (ship && (ship.x + dx < 40 || ship.x + dx > ship.W - 40)) dx = -dx;
      const dy = -rand(20, 40);
      c.dodge?.cancel();
      c.dodge = c.el.animate(
        [
          { translate: "0px 0px", easing: "cubic-bezier(.2,.9,.2,1)" },
          { translate: `${dx}px ${dy}px`, offset: 0.1 },
          { translate: `${dx}px ${dy}px`, offset: 0.4, easing: "ease-in-out" },
          { translate: "0px 0px" },
        ],
        { duration: 5200 }
      );
      setTimeout(() => c.el.classList.remove("is-spotted"), 900);
    }, 520);
  }

  // ---------------------------------------------------------------------
  // Shooting stars
  // ---------------------------------------------------------------------
  const starsOut = () => parseFloat(hero.style.getPropertyValue("--star-alpha") || "0") > 0.6;
  function meteorLoop() {
    if (live() && starsOut()) {
      launchMeteor();
      if (Math.random() < 0.18) setTimeout(launchMeteor, rand(250, 600));
    }
    setTimeout(meteorLoop, rand(5000, 11000));
  }
  setTimeout(meteorLoop, 3200);

  function launchMeteor() {
    const W = layer.clientWidth;
    const H = layer.clientHeight;
    const dir = Math.random() < 0.5 ? 1 : -1;
    const tilt = rand(16, 32);
    const deg = dir > 0 ? tilt : 180 - tilt;
    const len = rand(110, 170);
    const dist = rand(260, 420);
    const x0 = rand(0.12, 0.88) * W;
    const y0 = rand(0.04, 0.3) * H;
    const x1 = x0 + Math.cos(deg * DEG) * dist;
    const y1 = y0 + Math.sin(deg * DEG) * dist;
    const el = document.createElement("span");
    el.className = "meteor";
    el.style.setProperty("--len", `${len.toFixed(0)}px`);
    el.innerHTML = '<span class="meteor__hit"></span>';
    layer.append(el);
    const anim = el.animate(
      [
        { transform: `translate(${x0}px, ${y0}px) rotate(${deg}deg) scaleX(0.2)`, opacity: 0 },
        { transform: `translate(${x0 + (x1 - x0) * 0.12}px, ${y0 + (y1 - y0) * 0.12}px) rotate(${deg}deg) scaleX(1)`, opacity: 1, offset: 0.12 },
        { opacity: 1, offset: 0.75 },
        { transform: `translate(${x1}px, ${y1}px) rotate(${deg}deg) scaleX(0.6)`, opacity: 0 },
      ],
      { duration: rand(1400, 2000), easing: "cubic-bezier(.3,.2,.6,1)", fill: "forwards" }
    );
    const m = { el, hit: el.firstChild, anim };
    meteors.add(m);
    m.hit.addEventListener("pointerdown", (e) => {
      if (e.button !== 0) return;
      e.preventDefault();
      e.stopPropagation();
      wish(m);
    });
    anim.finished.then(() => {
      meteors.delete(m);
      el.remove();
    }, () => {});
  }
  function wish(m) {
    if (!meteors.has(m)) return;
    const p = local(m.hit.getBoundingClientRect());
    meteors.delete(m);
    m.anim.cancel();
    m.el.remove();
    burst(p.x + p.w / 2, p.y + p.h / 2, ["var(--c-craft-ray-3)", "var(--c-craft-lamp)", "var(--c-moon)", "var(--c-sky)"], "star");
    toast(pick(WISHES), { emoji: "🌠" });
  }

  // (wired last: subscribe() calls back straight away)
  // when day turns to night (or back), the current craft hurries off
  let wasNight = night();
  subscribe(({ minutes }) => {
    const n = isNight(minutes);
    if (n !== wasNight && current) current.anim.playbackRate = 5;
    if (!n) endSearch();
    wasNight = n;
    placeLighthouse();
  });

  schedule(2600); // after the sunrise intro
}
