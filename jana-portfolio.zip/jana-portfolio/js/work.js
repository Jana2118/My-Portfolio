/* work.js — "Ask me about this" prefills the desk letter; the design-system
   card's components are live (press, validate, flip theme). */
import { toast } from "./toast.js";
import { subscribe } from "./time-state.js";
import { isNight } from "./sky-palette.js";

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

export function initWork(section) {
  /* Ask → letter */
  for (const a of section.querySelectorAll("[data-ask]")) {
    a.addEventListener("click", (e) => {
      const letter = document.querySelector("[data-letter-message]");
      if (!letter) return;
      e.preventDefault();
      if (!letter.value.trim()) {
        letter.value = `Hi Jana, I'd love to hear more about ${a.dataset.ask}. `;
      }
      document.getElementById("letter")?.scrollIntoView({ behavior: matchMedia("(prefers-reduced-motion: reduce)").matches ? "auto" : "smooth", block: "center" });
      letter.focus({ preventScroll: true });
      letter.setSelectionRange(letter.value.length, letter.value.length);
    });
  }

  /* Design system card */
  const ds = section.querySelector("[data-ds]");
  if (!ds) return;
  for (const b of ds.querySelectorAll("[data-ds-press]")) {
    b.addEventListener("click", () => toast(`${b.textContent.trim()} button: pressed. Real HTML, real states.`, { emoji: "✅" }));
  }
  const email = ds.querySelector("[data-ds-email]");
  const msg = ds.querySelector("[data-ds-msg]");
  const validate = () => {
    const v = email.value.trim();
    if (!v) {
      email.removeAttribute("aria-invalid");
      msg.className = "field__msg";
      msg.textContent = "Type an email to see validation.";
    } else if (EMAIL_RE.test(v)) {
      email.setAttribute("aria-invalid", "false");
      msg.className = "field__msg is-ok";
      msg.textContent = "✓ Looks good.";
    } else {
      email.setAttribute("aria-invalid", "true");
      msg.className = "field__msg is-error";
      msg.textContent = "Add an @ and a domain, like name@site.com.";
    }
  };
  email?.addEventListener("input", validate);
  email?.addEventListener("blur", validate);

  /* "Flip theme": renders this card with the opposite palette, proving every
     colour is a token. Stays opposite if the sky changes the site theme. */
  const sw = ds.querySelector("[data-ds-switch]");
  let night = false;
  const apply = () => {
    if (sw.getAttribute("aria-checked") === "true") ds.dataset.theme = night ? "light" : "dark";
    else delete ds.dataset.theme;
  };
  subscribe(({ minutes }) => {
    night = isNight(minutes);
    if (sw) apply();
  });
  sw?.addEventListener("click", () => {
    sw.setAttribute("aria-checked", String(sw.getAttribute("aria-checked") !== "true"));
    apply();
  });
}
