/* ==========================================================================
   time-state.js — the single store for "what time is it in the sky".
   live  : follows the visitor's clock (default)
   manual: the visitor dragged the sun / used the slider (persisted)
   Applies the site theme and broadcasts changes to subscribers.
   ========================================================================== */
import { STORAGE } from "./config.js";
import { isNight } from "./sky-palette.js";

const listeners = new Set();
const root = document.documentElement;
const reduceMotion = matchMedia("(prefers-reduced-motion: reduce)");

const nowMinutes = () => {
  const d = new Date();
  return d.getHours() * 60 + d.getMinutes();
};

function read() {
  try {
    const s = JSON.parse(localStorage.getItem(STORAGE.sky) || "null");
    if (s && s.mode === "manual" && Number.isFinite(s.minutes)) {
      return { minutes: clamp(s.minutes), mode: "manual" };
    }
  } catch {
    /* storage blocked: fall through to live */
  }
  return { minutes: nowMinutes(), mode: "live" };
}

function write() {
  try {
    if (state.mode === "manual") {
      localStorage.setItem(STORAGE.sky, JSON.stringify({ minutes: Math.round(state.minutes), mode: "manual" }));
    } else {
      localStorage.removeItem(STORAGE.sky);
    }
  } catch {
    /* ignore */
  }
}

const clamp = (m) => ((Math.round(m) % 1440) + 1440) % 1440;

let state = read();
let tick = null;

function applyTheme() {
  const theme = isNight(state.minutes) ? "dark" : "light";
  if (root.dataset.theme !== theme) {
    if (!reduceMotion.matches && root.dataset.theme) {
      root.classList.add("theme-anim");
      clearTimeout(applyTheme.t);
      applyTheme.t = setTimeout(() => root.classList.remove("theme-anim"), 800);
    }
    root.dataset.theme = theme;
    const meta = document.querySelector('meta[name="theme-color"]');
    if (meta) meta.content = theme === "dark" ? "#0f1220" : "#f7f1e6";
  }
}

function emit() {
  applyTheme();
  for (const fn of listeners) fn(state);
}

function scheduleTick() {
  clearTimeout(tick);
  if (state.mode !== "live") return;
  const ms = 60000 - (Date.now() % 60000) + 50;
  tick = setTimeout(() => {
    state = { minutes: nowMinutes(), mode: "live" };
    emit();
    scheduleTick();
  }, ms);
}

export const getState = () => state;

/** Set the sky time. `persist` is false while dragging (written on release). */
export function setMinutes(minutes, { persist = true } = {}) {
  state = { minutes: clamp(minutes), mode: "manual" };
  clearTimeout(tick);
  if (persist) write();
  emit();
}

export function commit() {
  write();
}

export function resetToLive() {
  state = { minutes: nowMinutes(), mode: "live" };
  write();
  emit();
  scheduleTick();
}

export function subscribe(fn) {
  listeners.add(fn);
  fn(state);
  return () => listeners.delete(fn);
}

/* Keep other tabs/pages in sync. */
addEventListener("storage", (e) => {
  if (e.key !== STORAGE.sky) return;
  state = read();
  emit();
  scheduleTick();
});

applyTheme();
scheduleTick();
