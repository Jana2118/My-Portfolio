/* toast.js — one polite live region for short confirmations. */
let el;
let timer;

function ensure() {
  if (el) return el;
  el = document.querySelector("[data-toast]");
  if (!el) {
    el = document.createElement("div");
    el.className = "toast";
    el.dataset.toast = "";
    el.setAttribute("role", "status");
    el.setAttribute("aria-live", "polite");
    el.setAttribute("aria-atomic", "true");
    document.body.appendChild(el);
  }
  return el;
}

/** Show a message for ~3.2s. `emoji` is decorative and hidden from AT. */
export function toast(message, { emoji = "", duration = 3200 } = {}) {
  const t = ensure();
  t.classList.remove("is-on");
  t.textContent = "";
  // Re-insert text on the next frame so repeated messages are re-announced.
  requestAnimationFrame(() => {
    t.innerHTML = "";
    if (emoji) {
      const e = document.createElement("span");
      e.className = "emoji";
      e.setAttribute("aria-hidden", "true");
      e.textContent = emoji;
      t.append(e, " ");
    }
    t.append(message);
    t.classList.add("is-on");
  });
  clearTimeout(timer);
  timer = setTimeout(() => t.classList.remove("is-on"), duration);
}
